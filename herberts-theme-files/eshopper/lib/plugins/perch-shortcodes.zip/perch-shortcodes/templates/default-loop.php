<div class="tp-posts tp-posts-default-loop">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>

				<div id="tp-post-<?php the_ID(); ?>" class="tp-post">
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="tp-post-thumbnail" href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					<?php endif; ?>
					<h2 class="tp-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<div class="tp-post-meta"><?php _e( 'Posted', 'tp' ); ?>: <?php the_time( get_option( 'date_format' ) ); ?></div>
					<div class="tp-post-excerpt">
						<?php the_excerpt(); ?>
					</div>
					<a href="<?php comments_link(); ?>" class="tp-post-comments-link"><?php comments_number( __( '0 comments', 'tp' ), __( '1 comment', 'tp' ), '% comments' ); ?></a>
				</div>

				<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . __( 'Posts not found', 'tp' ) . '</h4>';
		}
	?>
</div>
jQuery(document).ready(function ($) {
	var initvl = 0;

	//counter up
     $('.counter-up-wrap .counter').counterUp({
          delay: 10,
          time: 1000
      });

     //skillbar
    $(window).scroll(function(){
    	$('.skillbar').each(function(){
	      if( $(this).visible() && !$(this).hasClass('animated') ) {
	        $(this).find('.skillbar-bar').animate({
	          width:$(this).attr('data-percent')
	        },2000);
	        $(this).addClass('animated');
	      }
	    });
    }) 
    

    //Testimonial slider
    if($(".owl-testimonials").length > 0 ){
    	 $(".owl-testimonials").owlCarousel({
          autoPlay : 3000,
          stopOnHover : true,
          navigation:true,
          paginationSpeed : 1000,
          goToFirstSpeed : 2000,
          singleItem : true,
          autoHeight : true,
          transitionStyle:"fade",
          navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]
      });
    }
    
     

	// Spoiler
	$('body:not(.tp-other-shortcodes-loaded)').on('click', '.tp-spoiler-title', function (e) {
		var $title = $(this),
			$spoiler = $title.parent(),
			bar = ($('#wpadminbar').length > 0) ? 28 : 0;
		// Open/close spoiler
		$spoiler.toggleClass('tp-spoiler-closed');
		// Close other spoilers in accordion
		$spoiler.parent('.tp-accordion').children('.tp-spoiler').not($spoiler).addClass('tp-spoiler-closed');
		// Scroll in spoiler in accordion
		if ($(window).scrollTop() > $title.offset().top) $(window).scrollTop($title.offset().top - $title.height() - bar);
		e.preventDefault();
	});
	$('.tp-spoiler-content').removeAttr('style');
	// Tabs
	$('body:not(.tp-other-shortcodes-loaded)').on('click', '.tp-tabs-nav span', function (e) {
		var $tab = $(this),
			data = $tab.data(),
			index = $tab.index(),
			is_disabled = $tab.hasClass('tp-tabs-disabled'),
			$tabs = $tab.parent('.tp-tabs-nav').children('span'),
			$panes = $tab.parents('.tp-tabs').find('.tp-tabs-pane'),
			$gmaps = $panes.eq(index).find('.tp-gmap:not(.tp-gmap-reloaded)');
		// Check tab is not disabled
		if (is_disabled) return false;
		// Hide all panes, show selected pane
		$panes.hide().eq(index).show();
		// Disable all tabs, enable selected tab
		$tabs.removeClass('tp-tabs-current').eq(index).addClass('tp-tabs-current');
		// Reload gmaps
		if ($gmaps.length > 0) $gmaps.each(function () {
			var $iframe = $(this).find('iframe:first');
			$(this).addClass('tp-gmap-reloaded');
			$iframe.attr('src', $iframe.attr('src'));
		});
		// Set height for vertical tabs
		tabs_height();
		// Open specified url
		if (data.url !== '') {
			if (data.target === 'self') window.location = data.url;
			else if (data.target === 'blank') window.open(data.url);
		}
		e.preventDefault();
		// here you need to rearrange the wall
		  setTimeout(function() {		    	
		    		
			$(window).trigger("resize");
						    	
		  }, 0);
		var initvl = 1;
		
	});

	// Activate tabs
	$('.tp-tabs').each(function () {
		var active = parseInt($(this).data('active')) - 1;
		$(this).children('.tp-tabs-nav').children('span').eq(active).trigger('click');

		tabs_height();
		
	});

	
	// Activate anchor nav for tabs and spoilers
	anchor_nav();

	// Lightbox
	$('.tp-lightbox').each(function () {
		$(this).on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();
			if ($(this).parent().attr('id') === 'tp-generator-preview') $(this).html(perch_other_shortcodes.no_preview);
			else {
				var type = $(this).data('mfp-type');
				$(this).magnificPopup({
					type: type,
					tClose: perch_magnific_popup.close,
					tLoading: perch_magnific_popup.loading,
					gallery: {
						tPrev: perch_magnific_popup.prev,
						tNext: perch_magnific_popup.next,
						tCounter: perch_magnific_popup.counter
					},
					image: {
						tError: perch_magnific_popup.error
					},
					ajax: {
						tError: perch_magnific_popup.error
					}
				}).magnificPopup('open');
			}
		});
	});
	// Tables
	$('.tp-table tr:even').addClass('tp-even');
	// Frame
	$('.tp-frame-align-center, .tp-frame-align-none').each(function () {
		var frame_width = $(this).find('img').width();
		$(this).css('width', frame_width + 12);
	});
	// Tooltip
	$('.tp-tooltip').each(function () {
		var $tt = $(this),
			$content = $tt.find('.tp-tooltip-content'),
			is_advanced = $content.length > 0,
			data = $tt.data(),
			config = {
				style: {
					classes: data.classes
				},
				position: {
					my: data.my,
					at: data.at,
					viewport: $(window)
				},
				content: {
					title: '',
					text: ''
				}
			};
		if (data.title !== '') config.content.title = data.title;
		if (is_advanced) config.content.text = $content;
		else config.content.text = $tt.attr('title');
		if (data.close === 'yes') config.content.button = true;
		if (data.behavior === 'click') {
			config.show = 'click';
			config.hide = 'click';
			$tt.on('click', function (e) {
				e.preventDefault();
				e.stopPropagation();
			});
			$(window).on('scroll resize', function () {
				$tt.qtip('reposition');
			});
		} else if (data.behavior === 'always') {
			config.show = true;
			config.hide = false;
			$(window).on('scroll resize', function () {
				$tt.qtip('reposition');
			});
		} else if (data.behavior === 'hover' && is_advanced) {
			config.hide = {
				fixed: true,
				delay: 600
			}
		}
		$tt.qtip(config);
	});

	// Expand
	$('.tp-expand').each(function () {
		var $this = $(this),
			$content = $this.children('.tp-expand-content'),
			$more = $this.children('.tp-expand-link-more'),
			$less = $this.children('.tp-expand-link-less'),
			data = $this.data(),
			col = 'tp-expand-collapsed';

		$more.on('click', function (e) {
			$content.css('max-height', 'none');
			$this.removeClass(col);
		});
		$less.on('click', function (e) {
			$content.css('max-height', data.height + 'px');
			$this.addClass(col);
		});
	});

	function is_transition_supported() {
		var thisBody = document.body || document.documentElement,
			thisStyle = thisBody.style,
			support = thisStyle.transition !== undefined || thisStyle.WebkitTransition !== undefined || thisStyle.MozTransition !== undefined || thisStyle.MsTransition !== undefined || thisStyle.OTransition !== undefined;

		return support;
	}

	// Animations is supported
	if (is_transition_supported()) {
		// Animate
		$('.tp-animate').each(function () {
			$(this).one('inview', function (e) {
				var $this = $(this),
					data = $this.data();
				window.setTimeout(function () {
					$this.addClass(data.animation);
					$this.addClass('animated');
					$this.css('visibility', 'visible');
				}, data.delay * 1000);
			});
		});
	}
	// Animations isn't supported
	else {
		$('.tp-animate').css('visibility', 'visible');
	}

	function tabs_height() {
		$('.tp-tabs-vertical').each(function () {
			var $tabs = $(this),
				$nav = $tabs.children('.tp-tabs-nav'),
				$panes = $tabs.find('.tp-tabs-pane'),
				height = 0;
			$panes.css('min-height', $nav.outerHeight(true));
		});
	}

	function anchor_nav() {
		// Check hash
		if (document.location.hash === '') return;
		// Go through tabs
		$('.tp-tabs-nav span[data-anchor]').each(function () {
			if ('#' + $(this).data('anchor') === document.location.hash) {
				var $tabs = $(this).parents('.tp-tabs'),
					bar = ($('#wpadminbar').length > 0) ? 28 : 0;
				// Activate tab
				$(this).trigger('click');
				// Scroll-in tabs container
				window.setTimeout(function () {
					$(window).scrollTop($tabs.offset().top - bar - 10);
				}, 100);
			}
		});
		// Go through spoilers
		$('.tp-spoiler[data-anchor]').each(function () {
			if ('#' + $(this).data('anchor') === document.location.hash) {
				var $spoiler = $(this),
					bar = ($('#wpadminbar').length > 0) ? 28 : 0;
				// Activate tab
				if ($spoiler.hasClass('tp-spoiler-closed')) $spoiler.find('.tp-spoiler-title:first').trigger('click');
				// Scroll-in tabs container
				window.setTimeout(function () {
					$(window).scrollTop($spoiler.offset().top - bar - 10);
				}, 100);
			}
		});
	}

	if ('onhashchange' in window) $(window).on('hashchange', anchor_nav);

	$('body').addClass('tp-other-shortcodes-loaded');
});


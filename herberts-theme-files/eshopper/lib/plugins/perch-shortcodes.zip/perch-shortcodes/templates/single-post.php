<div class="tp-posts tp-posts-single-post">
	<?php
		// Prepare marker to show only one post
		$first = true;
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;

				// Show oly first post
				if ( $first ) {
					$first = false;
					?>
					<div id="tp-post-<?php the_ID(); ?>" class="tp-post">
						<h1 class="tp-post-title"><?php the_title(); ?></h1>
						<div class="tp-post-meta"><?php _e( 'Posted', 'tp' ); ?>: <?php the_time( get_option( 'date_format' ) ); ?> | <a href="<?php comments_link(); ?>" class="tp-post-comments-link"><?php comments_number( __( '0 comments', 'tp' ), __( '1 comment', 'tp' ), __( '%n comments', 'tp' ) ); ?></a></div>
						<div class="tp-post-content">
							<?php the_content(); ?>
						</div>
					</div>
					<?php
				}
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . __( 'Posts not found', 'tp' ) . '</h4>';
		}
	?>
</div>
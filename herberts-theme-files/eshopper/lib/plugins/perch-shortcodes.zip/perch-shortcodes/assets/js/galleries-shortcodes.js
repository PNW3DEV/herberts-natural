jQuery(document).ready(function ($) {
	// Prepare items arrays for lightbox
	$('.tp-lightbox-gallery').each(function () {
		var slides = [];
		$(this).find('.tp-slider-slide, .tp-carousel-slide, .tp-custom-gallery-slide').each(function (i) {
			$(this).attr('data-index', i);
			slides.push({
				src: $(this).children('a').attr('href')
			});
		});
		$(this).data('slides', slides);
	});
	// Enable sliders
	$('.tp-slider').each(function () {
		// Prepare data
		var $slider = $(this);
		// Apply Swiper
		var $swiper = $slider.swiper({
			wrapperClass: 'tp-slider-slides',
			slideClass: 'tp-slider-slide',
			slideActiveClass: 'tp-slider-slide-active',
			slideVisibleClass: 'tp-slider-slide-visible',
			pagination: '#' + $slider.attr('id') + ' .tp-slider-pagination',
			autoplay: $slider.data('autoplay'),
			paginationClickable: true,
			grabCursor: true,
			mode: 'horizontal',
			mousewheelControl: $slider.data('mousewheel'),
			speed: $slider.data('speed'),
			calculateHeight: $slider.hasClass('tp-slider-responsive-yes'),
			loop: true
		});
		// Prev button
		$slider.find('.tp-slider-prev').click(function (e) {
			$swiper.swipeNext();
		});
		// Next button
		$slider.find('.tp-slider-next').click(function (e) {
			$swiper.swipePrev();
		});
	});
	// Enable carousels
	$('.tp-carousel').each(function () {
		// Prepare data
		var $carousel = $(this),
			$slides = $carousel.find('.tp-carousel-slide');


		if($carousel.hasClass('perch-posts-carousel')){
			
			$slider = $carousel.find('.tp-carousel-slides');
			 $slider.owlCarousel({
				items : $carousel.data('items'), //10 items above 1000px browser width,
				addClassActive: true,
				theme: "owl-theme",
			});
				 
				// Custom Navigation Events
			
				
		}else{	
			// Apply Swiper
			var $swiper = $carousel.swiper({
				wrapperClass: 'tp-carousel-slides',
				slideClass: 'tp-carousel-slide',
				slideActiveClass: 'tp-carousel-slide-active',
				slideVisibleClass: 'tp-carousel-slide-visible',
				pagination: '#' + $carousel.attr('id') + ' .tp-carousel-pagination',
				autoplay: $carousel.data('autoplay'),
				paginationClickable: true,
				grabCursor: true,
				mode: 'horizontal',
				mousewheelControl: $carousel.data('mousewheel'),
				speed: $carousel.data('speed'),
				slidesPerView: ($carousel.data('items') > $slides.length) ? $slides.length : $carousel.data('items'),
				slidesPerGroup: $carousel.data('scroll'),
				calculateHeight: $carousel.hasClass('tp-carousel-responsive-yes'),
				loop: true
			});
			// Prev button
			$carousel.find('.tp-carousel-prev').click(function (e) {
				$swiper.swipeNext();
			});
			// Next button
			$carousel.find('.tp-carousel-next').click(function (e) {
				$swiper.swipePrev();
			});
		}
	});
	// Enable lightbox
	$('.tp-lightbox-gallery').on('click', '.tp-slider-slide, .tp-carousel-slide, .tp-custom-gallery-slide', function (e) {
		e.preventDefault();
		var slides = $(this).parents('.tp-lightbox-gallery').data('slides');
		$.magnificPopup.open({
			items: slides,
			type: 'image',
			mainClass: 'mfp-img-mobile',
			gallery: {
				enabled: true,
				navigateByImgClick: true,
				preload: [0, 1],
				tPrev: perch_magnific_popup.prev,
				tNext: perch_magnific_popup.next,
				tCounter: perch_magnific_popup.counter
			},
			tClose: perch_magnific_popup.close,
			tLoading: perch_magnific_popup.loading
		}, $(this).data('index'));
	});
});
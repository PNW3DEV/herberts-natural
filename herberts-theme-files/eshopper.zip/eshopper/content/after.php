			</div>			
			<?php get_sidebar(); ?>			
		</div><!-- .row -->
	</div>
</section>
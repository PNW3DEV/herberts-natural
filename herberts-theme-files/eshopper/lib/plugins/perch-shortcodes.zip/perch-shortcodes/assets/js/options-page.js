// Wait DOM
jQuery(document).ready(function ($) {

	// ########## About screen ##########

	$('.tp-demo-video').magnificPopup({
		type: 'iframe',
		callbacks: {
			open: function () {
				// Change z-index
				$('body').addClass('tp-mfp-shown');
			},
			close: function () {
				// Change z-index
				$('body').removeClass('tp-mfp-shown');
			}
		}
	});

	// ########## Custom CSS screen ##########

	$('.tp-custom-css-originals a').magnificPopup({
		type: 'iframe',
		callbacks: {
			open: function () {
				// Change z-index
				$('body').addClass('tp-mfp-shown');
			},
			close: function () {
				// Change z-index
				$('body').removeClass('tp-mfp-shown');
			}
		}
	});

	// Enable ACE editor
	if ($('#sunrise-field-custom-css-editor').length > 0) {
		var editor = ace.edit('sunrise-field-custom-css-editor'),
			$textarea = $('#sunrise-field-custom-css').hide();
		editor.getSession().setValue($textarea.val());
		editor.getSession().on('change', function () {
			$textarea.val(editor.getSession().getValue());
		});
		editor.getSession().setMode('ace/mode/css');
		editor.setTheme('ace/theme/monokai');
		editor.getSession().setUseWrapMode(true);
		editor.getSession().setWrapLimitRange(null, null);
		editor.renderer.setShowPrintMargin(null);
		editor.session.setUseSoftTabs(null);
	}

	// ########## Add-ons screen ##########

	var addons_timer = 0;
	$('.tp-addons-item').each(function () {
		var $item = $(this),
			delay = 300;
		$item.click(function (e) {
			window.open($(this).data('url'));
			e.preventDefault();
		});
		addons_timer = addons_timer + delay;
		window.setTimeout(function () {
			$item.addClass('animated bounceIn').css('visibility', 'visible');
		}, addons_timer);
	});

	// ########## Examples screen ##########

	// Disable all buttons
	$('#tp-examples-preview').on('click', '.tp-button', function (e) {
		if ($(this).hasClass('tp-example-button-clicked')) alert(perch_options_page.not_clickable);
		else $(this).addClass('tp-example-button-clicked');
		e.preventDefault();
	});

	var open = $('#perch_open_example').val(),
		$example_window = $('#tp-examples-window'),
		$example_preview = $('#tp-examples-preview');
	$('.tp-examples-group-title, .tp-examples-item').each(function () {
		var $item = $(this),
			delay = 200;
		if ($item.hasClass('tp-examples-item')) {
			$item.on('click', function (e) {
				var code = $(this).data('code'),
					id = $(this).data('id');
				$item.magnificPopup({
					type: 'inline',
					alignTop: true,
					callbacks: {
						open: function () {
							// Change z-index
							$('body').addClass('tp-mfp-shown');
						},
						close: function () {
							// Change z-index
							$('body').removeClass('tp-mfp-shown');
							$example_preview.html('');
						}
					}
				});
				var perch_example_preview = $.ajax({
					url: ajaxurl,
					type: 'get',
					dataType: 'html',
					data: {
						action: 'perch_example_preview',
						code: code,
						id: id
					},
					beforeSend: function () {
						if (typeof perch_example_preview === 'object') perch_example_preview.abort();
						$example_window.addClass('tp-ajax');
						$item.magnificPopup('open');
					},
					success: function (data) {
						$example_preview.html(data);
						$example_window.removeClass('tp-ajax');
					}
				});
				e.preventDefault();
			});
			// Open preselected example
			if ($item.data('id') === open) $item.trigger('click');
		}
	});
	$('#tp-examples-window').on('click', '.tp-examples-get-code', function (e) {
		$(this).hide();
		$(this).parent('.tp-examples-code').children('textarea').slideDown(300);
		e.preventDefault();
	});

	// ########## Cheatsheet screen ##########
	$('.tp-cheatsheet-switch').on('click', function (e) {
		$('body').toggleClass('tp-print-cheatsheet');
		e.preventDefault();
	});
});
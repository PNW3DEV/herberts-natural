<?php
/**
 * Class for managing plugin data
 */
class Tp_Data {

	/**
	 * Constructor
	 */
	function __construct() {}

	/**
	 * Shortcode groups
	 */
	public static function groups() {
		return apply_filters( 'perch/data/groups', array(
				'all'     => __( 'All', 'tp' ),
				'content' => __( 'Content', 'tp' ),
				'box'     => __( 'Box', 'tp' ),
				'media'   => __( 'Media', 'tp' ),
				'gallery' => __( 'Gallery', 'tp' ),
				'data'    => __( 'Data', 'tp' ),
				'product'   => __( 'Product', 'tp' ),
				'other'   => __( 'Other', 'tp' )
			) );
	}

	/**
	 * Border styles
	 */
	public static function borders() {
		return apply_filters( 'perch/data/borders', array(
				'none'   => __( 'None', 'tp' ),
				'solid'  => __( 'Solid', 'tp' ),
				'dotted' => __( 'Dotted', 'tp' ),
				'dashed' => __( 'Dashed', 'tp' ),
				'double' => __( 'Double', 'tp' ),
				'groove' => __( 'Groove', 'tp' ),
				'ridge'  => __( 'Ridge', 'tp' )
			) );
	}

	/**
	 * Font-Awesome icons
	 */
	public static function icons() {
		return apply_filters( 'perch/data/icons', array( 'adjust', 'adn', 'align-center', 'align-justify', 'align-left', 'align-right', 'ambulance', 'anchor', 'android', 'angle-double-down', 'angle-double-left', 'angle-double-right', 'angle-double-up', 'angle-down', 'angle-left', 'angle-right', 'angle-up', 'apple', 'archive', 'arrow-circle-down', 'arrow-circle-left', 'arrow-circle-o-down', 'arrow-circle-o-left', 'arrow-circle-o-right', 'arrow-circle-o-up', 'arrow-circle-right', 'arrow-circle-up', 'arrow-down', 'arrow-left', 'arrow-right', 'arrow-up', 'arrows', 'arrows-alt', 'arrows-h', 'arrows-v', 'asterisk', 'automobile', 'backward', 'ban', 'bank', 'bar-chart-o', 'barcode', 'bars', 'beer', 'behance', 'behance-square', 'bell', 'bell-o', 'bitbucket', 'bitbucket-square', 'bitcoin', 'bold', 'bolt', 'bomb', 'book', 'bookmark', 'bookmark-o', 'briefcase', 'btc', 'bug', 'building', 'building-o', 'bullhorn', 'bullseye', 'cab', 'calendar', 'calendar-o', 'camera', 'camera-retro', 'car', 'caret-down', 'caret-left', 'caret-right', 'caret-square-o-down', 'caret-square-o-left', 'caret-square-o-right', 'caret-square-o-up', 'caret-up', 'certificate', 'chain', 'chain-broken', 'check', 'check-circle', 'check-circle-o', 'check-square', 'check-square-o', 'chevron-circle-down', 'chevron-circle-left', 'chevron-circle-right', 'chevron-circle-up', 'chevron-down', 'chevron-left', 'chevron-right', 'chevron-up', 'child', 'circle', 'circle-o', 'circle-o-notch', 'circle-thin', 'clipboard', 'clock-o', 'cloud', 'cloud-download', 'cloud-upload', 'cny', 'code', 'code-fork', 'codepen', 'coffee', 'cog', 'cogs', 'columns', 'comment', 'comment-o', 'comments', 'comments-o', 'compass', 'compress', 'copy', 'credit-card', 'crop', 'crosshairs', 'css3', 'cube', 'cubes', 'cut', 'cutlery', 'dashboard', 'database', 'dedent', 'delicious', 'desktop', 'deviantart', 'digg', 'dollar', 'dot-circle-o', 'download', 'dribbble', 'dropbox', 'drupal', 'edit', 'eject', 'ellipsis-h', 'ellipsis-v', 'empire', 'envelope', 'envelope-o', 'envelope-square', 'eraser', 'eur', 'euro', 'exchange', 'exclamation', 'exclamation-circle', 'exclamation-triangle', 'expand', 'external-link', 'external-link-square', 'eye', 'eye-slash', 'facebook', 'facebook-square', 'fast-backward', 'fast-forward', 'fax', 'female', 'fighter-jet', 'file', 'file-archive-o', 'file-audio-o', 'file-code-o', 'file-excel-o', 'file-image-o', 'file-movie-o', 'file-o', 'file-pdf-o', 'file-photo-o', 'file-picture-o', 'file-powerpoint-o', 'file-sound-o', 'file-text', 'file-text-o', 'file-video-o', 'file-word-o', 'file-zip-o', 'files-o', 'film', 'filter', 'fire', 'fire-extinguisher', 'flag', 'flag-checkered', 'flag-o', 'flash', 'flask', 'flickr', 'floppy-o', 'folder', 'folder-o', 'folder-open', 'folder-open-o', 'font', 'forward', 'foursquare', 'frown-o', 'gamepad', 'gavel', 'gbp', 'ge', 'gear', 'gears', 'gift', 'git', 'git-square', 'github', 'github-alt', 'github-square', 'gittip', 'glass', 'globe', 'google', 'google-plus', 'google-plus-square', 'graduation-cap', 'group', 'h-square', 'hacker-news', 'hand-o-down', 'hand-o-left', 'hand-o-right', 'hand-o-up', 'hdd-o', 'header', 'headphones', 'heart', 'heart-o', 'history', 'home', 'hospital-o', 'html5', 'image', 'inbox', 'indent', 'info', 'info-circle', 'inr', 'instagram', 'institution', 'italic', 'joomla', 'jpy', 'jsfiddle', 'key', 'keyboard-o', 'krw', 'language', 'laptop', 'leaf', 'legal', 'lemon-o', 'level-down', 'level-up', 'life-bouy', 'life-ring', 'life-saver', 'lightbulb-o', 'link', 'linkedin', 'linkedin-square', 'linux', 'list', 'list-alt', 'list-ol', 'list-ul', 'location-arrow', 'lock', 'long-arrow-down', 'long-arrow-left', 'long-arrow-right', 'long-arrow-up', 'magic', 'magnet', 'mail-forward', 'mail-reply', 'mail-reply-all', 'male', 'map-marker', 'maxcdn', 'medkit', 'meh-o', 'microphone', 'microphone-slash', 'minus', 'minus-circle', 'minus-square', 'minus-square-o', 'mobile', 'mobile-phone', 'money', 'moon-o', 'mortar-board', 'music', 'navicon', 'openid', 'outdent', 'pagelines', 'paper-plane', 'paper-plane-o', 'paperclip', 'paragraph', 'paste', 'pause', 'paw', 'pencil', 'pencil-square', 'pencil-square-o', 'phone', 'phone-square', 'photo', 'picture-o', 'pied-piper', 'pied-piper-alt', 'pied-piper-square', 'pinterest', 'pinterest-square', 'plane', 'play', 'play-circle', 'play-circle-o', 'plus', 'plus-circle', 'plus-square', 'plus-square-o', 'power-off', 'print', 'puzzle-piece', 'qq', 'qrcode', 'question', 'question-circle', 'quote-left', 'quote-right', 'ra', 'random', 'rebel', 'recycle', 'reddit', 'reddit-square', 'refresh', 'renren', 'reorder', 'repeat', 'reply', 'reply-all', 'retweet', 'rmb', 'road', 'rocket', 'rotate-left', 'rotate-right', 'rouble', 'rss', 'rss-square', 'rub', 'ruble', 'rupee', 'save', 'scissors', 'search', 'search-minus', 'search-plus', 'send', 'send-o', 'share', 'share-alt', 'share-alt-square', 'share-square', 'share-square-o', 'shield', 'shopping-cart', 'sign-in', 'sign-out', 'signal', 'sitemap', 'skype', 'slack', 'sliders', 'smile-o', 'sort', 'sort-alpha-asc', 'sort-alpha-desc', 'sort-amount-asc', 'sort-amount-desc', 'sort-asc', 'sort-desc', 'sort-down', 'sort-numeric-asc', 'sort-numeric-desc', 'sort-up', 'soundcloud', 'space-shuttle', 'spinner', 'spoon', 'spotify', 'square', 'square-o', 'stack-exchange', 'stack-overflow', 'star', 'star-half', 'star-half-empty', 'star-half-full', 'star-half-o', 'star-o', 'steam', 'steam-square', 'step-backward', 'step-forward', 'stethoscope', 'stop', 'strikethrough', 'stumbleupon', 'stumbleupon-circle', 'subscript', 'suitcase', 'sun-o', 'superscript', 'support', 'table', 'tablet', 'tachometer', 'tag', 'tags', 'tasks', 'taxi', 'tencent-weibo', 'terminal', 'text-height', 'text-width', 'th', 'th-large', 'th-list', 'thumb-tack', 'thumbs-down', 'thumbs-o-down', 'thumbs-o-up', 'thumbs-up', 'ticket', 'times', 'times-circle', 'times-circle-o', 'tint', 'toggle-down', 'toggle-left', 'toggle-right', 'toggle-up', 'trash-o', 'tree', 'trello', 'trophy', 'truck', 'try', 'tumblr', 'tumblr-square', 'turkish-lira', 'twitter', 'twitter-square', 'umbrella', 'underline', 'undo', 'university', 'unlink', 'unlock', 'unlock-alt', 'unsorted', 'upload', 'usd', 'user', 'user-md', 'users', 'video-camera', 'vimeo-square', 'vine', 'vk', 'volume-down', 'volume-off', 'volume-up', 'warning', 'wechat', 'weibo', 'weixin', 'wheelchair', 'windows', 'won', 'wordpress', 'wrench', 'xing', 'xing-square', 'yahoo', 'yen', 'youtube', 'youtube-play', 'youtube-square' ) );
	}

	/**
	 * Animate.css animations
	 */
	public static function animations() {
		return apply_filters( 'perch/data/animations', array( 'flash', 'bounce', 'shake', 'tada', 'swing', 'wobble', 'pulse', 'flip', 'flipInX', 'flipOutX', 'flipInY', 'flipOutY', 'fadeIn', 'fadeInUp', 'fadeInDown', 'fadeInLeft', 'fadeInRight', 'fadeInUpBig', 'fadeInDownBig', 'fadeInLeftBig', 'fadeInRightBig', 'fadeOut', 'fadeOutUp', 'fadeOutDown', 'fadeOutLeft', 'fadeOutRight', 'fadeOutUpBig', 'fadeOutDownBig', 'fadeOutLeftBig', 'fadeOutRightBig', 'slideInDown', 'slideInLeft', 'slideInRight', 'slideOutUp', 'slideOutLeft', 'slideOutRight', 'bounceIn', 'bounceInDown', 'bounceInUp', 'bounceInLeft', 'bounceInRight', 'bounceOut', 'bounceOutDown', 'bounceOutUp', 'bounceOutLeft', 'bounceOutRight', 'rotateIn', 'rotateInDownLeft', 'rotateInDownRight', 'rotateInUpLeft', 'rotateInUpRight', 'rotateOut', 'rotateOutDownLeft', 'rotateOutDownRight', 'rotateOutUpLeft', 'rotateOutUpRight', 'lightSpeedIn', 'lightSpeedOut', 'hinge', 'rollIn', 'rollOut' ) );
	}

	/**
	 * Examples section
	 */
	public static function examples() {
		return apply_filters( 'perch/data/examples', array(
				'basic' => array(
					'title' => __( 'Basic examples', 'tp' ),
					'items' => array(
						array(
							'name' => __( 'Accordions, spoilers, different styles, anchors', 'tp' ),
							'id'   => 'spoilers',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/spoilers.example',
							'icon' => 'tasks'
						),
						array(
							'name' => __( 'Tabs, vertical tabs, tab anchors', 'tp' ),
							'id'   => 'tabs',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/tabs.example',
							'icon' => 'folder'
						),
						array(
							'name' => __( 'Column layouts', 'tp' ),
							'id'   => 'columns',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/columns.example',
							'icon' => 'th-large'
						),
						array(
							'name' => __( 'Media elements, YouTube, Vimeo, Screenr and self-hosted videos, audio player', 'tp' ),
							'id'   => 'media',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/media.example',
							'icon' => 'play-circle'
						),
						array(
							'name' => __( 'Unlimited buttons', 'tp' ),
							'id'   => 'buttons',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/buttons.example',
							'icon' => 'heart',

						),
						array(
							'name' => __( 'Animations', 'tp' ),
							'id'   => 'animations',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/animations.example',
							'icon' => 'bolt'
						),
					)
				),
				'advanced' => array(
					'title' => __( 'Advanced examples', 'tp' ),
					'items' => array(
						array(
							'name' => __( 'Interacting with posts shortcode', 'tp' ),
							'id' => 'posts',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/posts.example',
							'icon' => 'list'
						),
						array(
							'name' => __( 'Nested shortcodes, shortcodes inside of attributes', 'tp' ),
							'id' => 'nested',
							'code' => plugin_dir_path( TP_PLUGIN_FILE ) . '/inc/examples/nested.example',
							'icon' => 'indent'
						),
					)
				),
			) );
	}

	/**
	 * Shortcodes
	 */
	public static function shortcodes( $shortcode = false ) {
		$shortcodes = apply_filters( 'perch/data/shortcodes', array(
				// heading
				'heading' => array(
					'name' => __( 'Heading', 'tp' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								 'style2' => __( 'style 2', 'tp' ),
							),
							'default' => 'style2',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Choose style for this heading', 'tp' ) 
						),
						'tag' => array(
							'type' => 'select',
							'values' => array(
								'h1' => __( 'H1', 'tp' ),
								'h2' => __( 'H2', 'tp' ),
								'h3' => __( 'H3', 'tp' ),
								'h4' => __( 'H4', 'tp' ),
								'h5' => __( 'H5', 'tp' ),
								'h6' => __( 'H6', 'tp' ),
							),
							'default' => 'h3',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Choose style for this heading', 'tp' ) 
						),
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'tp' ),
								'center' => __( 'Center', 'tp' ),
								'right' => __( 'Right', 'tp' )
							),
							'default' => 'center',
							'name' => __( 'Align', 'tp' ),
							'desc' => __( 'Heading text alignment', 'tp' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 200,
							'step' => 10,
							'default' => 20,
							'name' => __( 'Margin', 'tp' ),
							'desc' => __( 'Bottom margin (pixels)', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Heading text', 'tp' ),
					'desc' => __( 'Styled heading', 'tp' ),
					'icon' => 'h-square'
				),				
				// tabs
				'tabs' => array(
					'name' => __( 'Tabs', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'2' => __( 'Style 2', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Choose style for this tabs', 'tp' ) 
						),
						'active' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 1,
							'name' => __( 'Active tab', 'tp' ),
							'desc' => __( 'Select which tab is open by default', 'tp' )
						),
						'vertical' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Vertical', 'tp' ),
							'desc' => __( 'Show tabs vertically', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( "[%prefix_tab title=\"Title 1\"]Content 1[/%prefix_tab]\n[%prefix_tab title=\"Title 2\"]Content 2[/%prefix_tab]\n[%prefix_tab title=\"Title 3\"]Content 3[/%prefix_tab]", 'tp' ),
					'desc' => __( 'Tabs container', 'tp' ),
					'example' => 'tabs',
					'icon' => 'list-alt'
				),
				// tab
				'tab' => array(
					'name' => __( 'Tab', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => __( 'Tab name', 'tp' ),
							'name' => __( 'Title', 'tp' ),
							'desc' => __( 'Enter tab name', 'tp' )
						),
						'disabled' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Disabled', 'tp' ),
							'desc' => __( 'Is this tab disabled', 'tp' )
						),
						'anchor' => array(
							'default' => '',
							'name' => __( 'Anchor', 'tp' ),
							'desc' => __( 'You can use unique anchor for this tab to access it with hash in page url. For example: type here <b%value>Hello</b> and then use url like http://example.com/page-url#Hello. This tab will be activated and scrolled in', 'tp' )
						),
						'url' => array(
							'default' => '',
							'name' => __( 'URL', 'tp' ),
							'desc' => __( 'You can link this tab to any webpage. Enter here full URL to switch this tab into link', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self'  => __( 'Open link in same window/tab', 'tp' ),
								'blank' => __( 'Open link in new window/tab', 'tp' )
							),
							'default' => 'blank',
							'name' => __( 'Link target', 'tp' ),
							'desc' => __( 'Choose how to open the custom tab link', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Tab content', 'tp' ),
					'desc' => __( 'Single tab', 'tp' ),
					'note' => __( 'Did you know that you need to wrap single tabs with [tabs] shortcode?', 'tp' ),
					'example' => 'tabs',
					'icon' => 'list-alt'
				),
				// spoiler
				'spoiler' => array(
					'name' => __( 'Spoiler', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => __( 'Spoiler title', 'tp' ),
							'name' => __( 'Title', 'tp' ), 'desc' => __( 'Text in spoiler title', 'tp' )
						),
						'open' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Open', 'tp' ),
							'desc' => __( 'Is spoiler content visible by default', 'tp' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'fancy' => __( 'Fancy', 'tp' ),
								'simple' => __( 'Simple', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Choose style for this spoiler', 'tp' ) 
						),
						'icon' => array(
							'type' => 'select',
							'values' => array(
								'plus'           => __( 'Plus', 'tp' ),
								'plus-circle'    => __( 'Plus circle', 'tp' ),
								'plus-square-1'  => __( 'Plus square 1', 'tp' ),
								'plus-square-2'  => __( 'Plus square 2', 'tp' ),
								'arrow'          => __( 'Arrow', 'tp' ),
								'arrow-circle-1' => __( 'Arrow circle 1', 'tp' ),
								'arrow-circle-2' => __( 'Arrow circle 2', 'tp' ),
								'chevron'        => __( 'Chevron', 'tp' ),
								'chevron-circle' => __( 'Chevron circle', 'tp' ),
								'caret'          => __( 'Caret', 'tp' ),
								'caret-square'   => __( 'Caret square', 'tp' ),
								'folder-1'       => __( 'Folder 1', 'tp' ),
								'folder-2'       => __( 'Folder 2', 'tp' )
							),
							'default' => 'plus',
							'name' => __( 'Icon', 'tp' ),
							'desc' => __( 'Icons for spoiler', 'tp' )
						),
						'anchor' => array(
							'default' => '',
							'name' => __( 'Anchor', 'tp' ),
							'desc' => __( 'You can use unique anchor for this spoiler to access it with hash in page url. For example: type here <b%value>Hello</b> and then use url like http://example.com/page-url#Hello. This spoiler will be open and scrolled in', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Hidden content', 'tp' ),
					'desc' => __( 'Spoiler with hidden content', 'tp' ),
					'note' => __( 'Did you know that you can wrap multiple spoilers with [accordion] shortcode to create accordion effect?', 'tp' ),
					'example' => 'spoilers',
					'icon' => 'list-ul'
				),
				// accordion
				'accordion' => array(
					'name' => __( 'Accordion', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( "[%prefix_spoiler]Content[/%prefix_spoiler]\n[%prefix_spoiler]Content[/%prefix_spoiler]\n[%prefix_spoiler]Content[/%prefix_spoiler]", 'tp' ),
					'desc' => __( 'Accordion with spoilers', 'tp' ),
					'note' => __( 'Did you know that you can wrap multiple spoilers with [accordion] shortcode to create accordion effect?', 'tp' ),
					'example' => 'spoilers',
					'icon' => 'list'
				),
				// divider
				'divider' => array(
					'name' => __( 'Divider', 'tp' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'top' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show TOP link', 'tp' ),
							'desc' => __( 'Show link to top of the page or not', 'tp' )
						),
						'text' => array(
							'values' => array( ),
							'default' => __( 'Go to top', 'tp' ),
							'name' => __( 'Link text', 'tp' ), 'desc' => __( 'Text for the GO TOP link', 'tp' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'dotted'  => __( 'Dotted', 'tp' ),
								'dashed'  => __( 'Dashed', 'tp' ),
								'double'  => __( 'Double', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Choose style for this divider', 'tp' )
						),
						'divider_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#999999',
							'name' => __( 'Divider color', 'tp' ),
							'desc' => __( 'Pick the color for divider', 'tp' )
						),
						'link_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#999999',
							'name' => __( 'Link color', 'tp' ),
							'desc' => __( 'Pick the color for TOP link', 'tp' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 40,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'tp' ),
							'desc' => __( 'Height of the divider (in pixels)', 'tp' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 200,
							'step' => 5,
							'default' => 15,
							'name' => __( 'Margin', 'tp' ),
							'desc' => __( 'Adjust the top and bottom margins of this divider (in pixels)', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Content divider with optional TOP link', 'tp' ),
					'icon' => 'ellipsis-h'
				),
				// spacer
				'spacer' => array(
					'name' => __( 'Spacer', 'tp' ),
					'type' => 'single',
					'group' => 'content other',
					'atts' => array(
						'size' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 800,
							'step' => 10,
							'default' => 20,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Height of the spacer in pixels', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Empty space with adjustable height', 'tp' ),
					'icon' => 'arrows-v'
				),
				// highlight
				'highlight' => array(
					'name' => __( 'Highlight', 'tp' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#DDFF99',
							'name' => __( 'Background', 'tp' ),
							'desc' => __( 'Highlighted text background color', 'tp' )
						),
						'color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#000000',
							'name' => __( 'Text color', 'tp' ), 'desc' => __( 'Highlighted text color', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Highlighted text', 'tp' ),
					'desc' => __( 'Highlighted text', 'tp' ),
					'icon' => 'pencil'
				),
				// label
				'label' => array(
					'name' => __( 'Label', 'tp' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'success' => __( 'Success', 'tp' ),
								'warning' => __( 'Warning', 'tp' ),
								'important' => __( 'Important', 'tp' ),
								'black' => __( 'Black', 'tp' ),
								'info' => __( 'Info', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Type', 'tp' ),
							'desc' => __( 'Style of the label', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Label', 'tp' ),
					'desc' => __( 'Styled label', 'tp' ),
					'icon' => 'tag'
				),
				// quote
				'quote' => array(
					'name' => __( 'Quote', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Choose style for this quote', 'tp' ) 
						),
						'cite' => array(
							'default' => '',
							'name' => __( 'Cite', 'tp' ),
							'desc' => __( 'Quote author name', 'tp' )
						),
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Cite url', 'tp' ),
							'desc' => __( 'Url of the quote author. Leave empty to disable link', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Quote', 'tp' ),
					'desc' => __( 'Blockquote alternative', 'tp' ),
					'icon' => 'quote-right'
				),
				// pullquote
				'pullquote' => array(
					'name' => __( 'Pullquote', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'tp' ),
								'right' => __( 'Right', 'tp' )
							),
							'default' => 'left',
							'name' => __( 'Align', 'tp' ), 'desc' => __( 'Pullquote alignment (float)', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Pullquote', 'tp' ),
					'desc' => __( 'Pullquote', 'tp' ),
					'icon' => 'quote-left'
				),
				// dropcap
				'dropcap' => array(
					'name' => __( 'Dropcap', 'tp' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'flat' => __( 'Flat', 'tp' ),
								'light' => __( 'Light', 'tp' ),
								'simple' => __( 'Simple', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'tp' ), 'desc' => __( 'Dropcap style preset', 'tp' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 5,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'tp' ),
							'desc' => __( 'Choose dropcap size', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'D', 'tp' ),
					'desc' => __( 'Dropcap', 'tp' ),
					'icon' => 'bold'
				),
				// frame
				'frame' => array(
					'name' => __( 'Frame', 'tp' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'tp' ),
								'center' => __( 'Center', 'tp' ),
								'right' => __( 'Right', 'tp' )
							),
							'default' => 'left',
							'name' => __( 'Align', 'tp' ),
							'desc' => __( 'Frame alignment', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => '<img src="http://lorempixel.com/g/400/200/" />',
					'desc' => __( 'Styled image frame', 'tp' ),
					'icon' => 'picture-o'
				),
				// row
				'row' => array(
					'name' => __( 'Row', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( "[%prefix_column size=\"1/3\"]Content[/%prefix_column]\n[%prefix_column size=\"1/3\"]Content[/%prefix_column]\n[%prefix_column size=\"1/3\"]Content[/%prefix_column]", 'tp' ),
					'desc' => __( 'Row for flexible columns', 'tp' ),
					'icon' => 'columns'
				),
				// column
				'column' => array(
					'name' => __( 'Column', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'size' => array(
							'type' => 'select',
							'values' => array(
								'1/1' => __( 'Full width', 'tp' ),
								'1/2' => __( 'One half', 'tp' ),
								'1/3' => __( 'One third', 'tp' ),
								'2/3' => __( 'Two third', 'tp' ),
								'1/4' => __( 'One fourth', 'tp' ),
								'3/4' => __( 'Three fourth', 'tp' ),
								'1/5' => __( 'One fifth', 'tp' ),
								'2/5' => __( 'Two fifth', 'tp' ),
								'3/5' => __( 'Three fifth', 'tp' ),
								'4/5' => __( 'Four fifth', 'tp' ),
								'1/6' => __( 'One sixth', 'tp' ),
								'5/6' => __( 'Five sixth', 'tp' )
							),
							'default' => '1/2',
							'name' => __( 'Size', 'tp' ),
							'desc' => __( 'Select column width. This width will be calculated depend page width', 'tp' )
						),
						'center' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Centered', 'tp' ),
							'desc' => __( 'Is this column centered on the page', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Column content', 'tp' ),
					'desc' => __( 'Flexible and responsive columns', 'tp' ),
					'note' => __( 'Did you know that you need to wrap columns with [row] shortcode?', 'tp' ),
					'example' => 'columns',
					'icon' => 'columns'
				),
				// list
				'list' => array(
					'name' => __( 'List', 'tp' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'tp' ),
							'desc' => __( 'You can upload custom icon for this list or pick a built-in icon', 'tp' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon color', 'tp' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( "<ul>\n<li>List item</li>\n<li>List item</li>\n<li>List item</li>\n</ul>", 'tp' ),
					'desc' => __( 'Styled unordered list', 'tp' ),
					'icon' => 'list-ol'
				),
				// button
				'button' => array(
					'name' => __( 'Button', 'tp' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => get_option( 'home' ),
							'name' => __( 'Link', 'tp' ),
							'desc' => __( 'Button link', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same tab', 'tp' ),
								'blank' => __( 'New tab', 'tp' )
							),
							'default' => 'self',
							'name' => __( 'Target', 'tp' ),
							'desc' => __( 'Button link target', 'tp' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'flat' => __( 'Flat', 'tp' ),
								'ghost' => __( 'Ghost', 'tp' ),
								'soft' => __( 'Soft', 'tp' ),
								'glass' => __( 'Glass', 'tp' ),
								'bubbles' => __( 'Bubbles', 'tp' ),
								'noise' => __( 'Noise', 'tp' ),
								'stroked' => __( 'Stroked', 'tp' ),
								'3d' => __( '3D', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'tp' ), 'desc' => __( 'Button background style preset', 'tp' )
						),
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#2D89EF',
							'name' => __( 'Background', 'tp' ), 'desc' => __( 'Button background color', 'tp' )
						),
						'color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Text color', 'tp' ),
							'desc' => __( 'Button text color', 'tp' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'tp' ),
							'desc' => __( 'Button size', 'tp' )
						),
						'wide' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Fluid', 'tp' ), 'desc' => __( 'Fluid buttons has 100% width', 'tp' )
						),
						'center' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Centered', 'tp' ), 'desc' => __( 'Is button centered on the page', 'tp' )
						),
						'radius' => array(
							'type' => 'select',
							'values' => array(
								'auto' => __( 'Auto', 'tp' ),
								'round' => __( 'Round', 'tp' ),
								'0' => __( 'Square', 'tp' ),
								'5' => '5px',
								'10' => '10px',
								'20' => '20px'
							),
							'default' => 'auto',
							'name' => __( 'Radius', 'tp' ),
							'desc' => __( 'Radius of button corners. Auto-radius calculation based on button size', 'tp' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'tp' ),
							'desc' => __( 'You can upload custom icon for this button or pick a built-in icon', 'tp' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#FFFFFF',
							'name' => __( 'Icon color', 'tp' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'tp' )
						),
						'text_shadow' => array(
							'type' => 'shadow',
							'default' => 'none',
							'name' => __( 'Text shadow', 'tp' ),
							'desc' => __( 'Button text shadow', 'tp' )
						),
						'desc' => array(
							'default' => '',
							'name' => __( 'Description', 'tp' ),
							'desc' => __( 'Small description under button text. This option is incompatible with icon.', 'tp' )
						),
						'onclick' => array(
							'default' => '',
							'name' => __( 'onClick', 'tp' ),
							'desc' => __( 'Advanced JavaScript code for onClick action', 'tp' )
						),
						'rel' => array(
							'default' => '',
							'name' => __( 'Rel attribute', 'tp' ),
							'desc' => __( 'Here you can add value for the rel attribute.<br>Example values: <b%value>nofollow</b>, <b%value>lightbox</b>', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Button text', 'tp' ),
					'desc' => __( 'Styled button', 'tp' ),
					'example' => 'buttons',
					'icon' => 'heart'
				),
				// service
				'service' => array(
					'name' => __( 'Service', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'values' => array( ),
							'default' => __( 'Service title', 'tp' ),
							'name' => __( 'Title', 'tp' ),
							'desc' => __( 'Service name', 'tp' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'tp' ),
							'desc' => __( 'You can upload custom icon for this box', 'tp' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon color', 'tp' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'tp' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 128,
							'step' => 2,
							'default' => 32,
							'name' => __( 'Icon size', 'tp' ),
							'desc' => __( 'Size of the uploaded icon in pixels', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Service description', 'tp' ),
					'desc' => __( 'Service box with title', 'tp' ),
					'icon' => 'check-square-o'
				),
				// box
				'box' => array(
					'name' => __( 'Box', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'values' => array( ),
							'default' => __( 'Box title', 'tp' ),
							'name' => __( 'Title', 'tp' ), 'desc' => __( 'Text for the box title', 'tp' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'soft' => __( 'Soft', 'tp' ),
								'glass' => __( 'Glass', 'tp' ),
								'bubbles' => __( 'Bubbles', 'tp' ),
								'noise' => __( 'Noise', 'tp' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Box style preset', 'tp' )
						),
						'box_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Color', 'tp' ),
							'desc' => __( 'Color for the box title and borders', 'tp' )
						),
						'title_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Title text color', 'tp' ), 'desc' => __( 'Color for the box title text', 'tp' )
						),
						'radius' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Radius', 'tp' ),
							'desc' => __( 'Box corners radius', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Box content', 'tp' ),
					'desc' => __( 'Colored box with caption', 'tp' ),
					'icon' => 'list-alt'
				),
				// note
				'note' => array(
					'name' => __( 'Note', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'note_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFF66',
							'name' => __( 'Background', 'tp' ), 'desc' => __( 'Note background color', 'tp' )
						),
						'text_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Text color', 'tp' ),
							'desc' => __( 'Note text color', 'tp' )
						),
						'radius' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Radius', 'tp' ), 'desc' => __( 'Note corners radius', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Note text', 'tp' ),
					'desc' => __( 'Colored box', 'tp' ),
					'icon' => 'list-alt'
				),
				// expand
				'expand' => array(
					'name' => __( 'Expand', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'more_text' => array(
							'default' => __( 'Show more', 'tp' ),
							'name' => __( 'More text', 'tp' ),
							'desc' => __( 'Enter the text for more link', 'tp' )
						),
						'less_text' => array(
							'default' => __( 'Show less', 'tp' ),
							'name' => __( 'Less text', 'tp' ),
							'desc' => __( 'Enter the text for less link', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1000,
							'step' => 10,
							'default' => 100,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Height for collapsed state (in pixels)', 'tp' )
						),
						'hide_less' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Hide less link', 'tp' ),
							'desc' => __( 'This option allows you to hide less link, when the text block has been expanded', 'tp' )
						),
						'text_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Text color', 'tp' ),
							'desc' => __( 'Pick the text color', 'tp' )
						),
						'link_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#0088FF',
							'name' => __( 'Link color', 'tp' ),
							'desc' => __( 'Pick the link color', 'tp' )
						),
						'link_style' => array(
							'type' => 'select',
							'values' => array(
								'default'    => __( 'Default', 'tp' ),
								'underlined' => __( 'Underlined', 'tp' ),
								'dotted'     => __( 'Dotted', 'tp' ),
								'dashed'     => __( 'Dashed', 'tp' ),
								'button'     => __( 'Button', 'tp' ),
							),
							'default' => 'default',
							'name' => __( 'Link style', 'tp' ),
							'desc' => __( 'Select the style for more/less link', 'tp' )
						),
						'link_align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'tp' ),
								'center' => __( 'Center', 'tp' ),
								'right' => __( 'Right', 'tp' ),
							),
							'default' => 'left',
							'name' => __( 'Link align', 'tp' ),
							'desc' => __( 'Select link alignment', 'tp' )
						),
						'more_icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'More icon', 'tp' ),
							'desc' => __( 'Add an icon to the more link', 'tp' )
						),
						'less_icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Less icon', 'tp' ),
							'desc' => __( 'Add an icon to the less link', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'This text block can be expanded', 'tp' ),
					'desc' => __( 'Expandable text block', 'tp' ),
					'icon' => 'sort-amount-asc'
				),
				// lightbox
				'lightbox' => array(
					'name' => __( 'Lightbox', 'tp' ),
					'type' => 'wrap',
					'group' => 'gallery',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'iframe' => __( 'Iframe', 'tp' ),
								'image' => __( 'Image', 'tp' ),
								'inline' => __( 'Inline (html content)', 'tp' )
							),
							'default' => 'iframe',
							'name' => __( 'Content type', 'tp' ),
							'desc' => __( 'Select type of the lightbox window content', 'tp' )
						),
						'src' => array(
							'default' => '',
							'name' => __( 'Content source', 'tp' ),
							'desc' => __( 'Insert here URL or CSS selector. Use URL for Iframe and Image content types. Use CSS selector for Inline content type.<br />Example values:<br /><b%value>http://www.youtube.com/watch?v=XXXXXXXXX</b> - YouTube video (iframe)<br /><b%value>http://example.com/wp-content/uploads/image.jpg</b> - uploaded image (image)<br /><b%value>http://example.com/</b> - any web page (iframe)<br /><b%value>#my-custom-popup</b> - any HTML content (inline)', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( '[%prefix_button] Click Here to Watch the Video [/%prefix_button]', 'tp' ),
					'desc' => __( 'Lightbox window with custom content', 'tp' ),
					'icon' => 'external-link'
				),
				// lightbox content
				'lightbox_content' => array(
					'name' => __( 'Lightbox content', 'tp' ),
					'type' => 'wrap',
					'group' => 'gallery',
					'atts' => array(
						'id' => array(
							'default' => '',
							'name' => __( 'ID', 'tp' ),
							'desc' => sprintf( __( 'Enter here the ID from Content source field. %s Example value: %s', 'tp' ), '<br>', '<b%value>my-custom-popup</b>' )
						),
						'width' => array(
							'default' => '50%',
							'name' => __( 'Width', 'tp' ),
							'desc' => sprintf( __( 'Adjust the width for inline content (in pixels or percents). %s Example values: %s, %s, %s', 'tp' ), '<br>', '<b%value>300px</b>', '<b%value>600px</b>', '<b%value>90%</b>' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 600,
							'step' => 5,
							'default' => 40,
							'name' => __( 'Margin', 'tp' ),
							'desc' => __( 'Adjust the margin for inline content (in pixels)', 'tp' )
						),
						'padding' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 600,
							'step' => 5,
							'default' => 40,
							'name' => __( 'Padding', 'tp' ),
							'desc' => __( 'Adjust the padding for inline content (in pixels)', 'tp' )
						),
						'text_align' => array(
							'type' => 'select',
							'values' => array(
								'left'   => __( 'Left', 'tp' ),
								'center' => __( 'Center', 'tp' ),
								'right'  => __( 'Right', 'tp' )
							),
							'default' => 'center',
							'name' => __( 'Text alignment', 'tp' ),
							'desc' => __( 'Select the text alignment', 'tp' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#FFFFFF',
							'name' => __( 'Background color', 'tp' ),
							'desc' => __( 'Pick a background color', 'tp' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Text color', 'tp' ),
							'desc' => __( 'Pick a text color', 'tp' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Text color', 'tp' ),
							'desc' => __( 'Pick a text color', 'tp' )
						),
						'shadow' => array(
							'type' => 'shadow',
							'default' => '0px 0px 15px #333333',
							'name' => __( 'Shadow', 'tp' ),
							'desc' => __( 'Adjust the shadow for content box', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Inline content', 'tp' ),
					'desc' => __( 'Inline content for lightbox', 'tp' ),
					'icon' => 'external-link'
				),
				// tooltip
				'tooltip' => array(
					'name' => __( 'Tooltip', 'tp' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'light' => __( 'Basic: Light', 'tp' ),
								'dark' => __( 'Basic: Dark', 'tp' ),
								'yellow' => __( 'Basic: Yellow', 'tp' ),
								'green' => __( 'Basic: Green', 'tp' ),
								'red' => __( 'Basic: Red', 'tp' ),
								'blue' => __( 'Basic: Blue', 'tp' ),
								'youtube' => __( 'Youtube', 'tp' ),
								'tipsy' => __( 'Tipsy', 'tp' ),
								'bootstrap' => __( 'Bootstrap', 'tp' ),
								'jtools' => __( 'jTools', 'tp' ),
								'tipped' => __( 'Tipped', 'tp' ),
								'cluetip' => __( 'Cluetip', 'tp' ),
							),
							'default' => 'yellow',
							'name' => __( 'Style', 'tp' ),
							'desc' => __( 'Tooltip window style', 'tp' )
						),
						'position' => array(
							'type' => 'select',
							'values' => array(
								'north' => __( 'Top', 'tp' ),
								'south' => __( 'Bottom', 'tp' ),
								'west' => __( 'Left', 'tp' ),
								'east' => __( 'Right', 'tp' )
							),
							'default' => 'top',
							'name' => __( 'Position', 'tp' ),
							'desc' => __( 'Tooltip position', 'tp' )
						),
						'shadow' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Shadow', 'tp' ),
							'desc' => __( 'Add shadow to tooltip. This option is only works with basic styes, e.g. blue, green etc.', 'tp' )
						),
						'rounded' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Rounded corners', 'tp' ),
							'desc' => __( 'Use rounded for tooltip. This option is only works with basic styes, e.g. blue, green etc.', 'tp' )
						),
						'size' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'tp' ),
								'1' => 1,
								'2' => 2,
								'3' => 3,
								'4' => 4,
								'5' => 5,
								'6' => 6,
							),
							'default' => 'default',
							'name' => __( 'Font size', 'tp' ),
							'desc' => __( 'Tooltip font size', 'tp' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Tooltip title', 'tp' ),
							'desc' => __( 'Enter title for tooltip window. Leave this field empty to hide the title', 'tp' )
						),
						'content' => array(
							'default' => __( 'Tooltip text', 'tp' ),
							'name' => __( 'Tooltip content', 'tp' ),
							'desc' => __( 'Enter tooltip content here', 'tp' )
						),
						'behavior' => array(
							'type' => 'select',
							'values' => array(
								'hover' => __( 'Show and hide on mouse hover', 'tp' ),
								'click' => __( 'Show and hide by mouse click', 'tp' ),
								'always' => __( 'Always visible', 'tp' )
							),
							'default' => 'hover',
							'name' => __( 'Behavior', 'tp' ),
							'desc' => __( 'Select tooltip behavior', 'tp' )
						),
						'close' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Close button', 'tp' ),
							'desc' => __( 'Show close button', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( '[%prefix_button] Hover me to open tooltip [/%prefix_button]', 'tp' ),
					'desc' => __( 'Tooltip window with custom content', 'tp' ),
					'icon' => 'comment-o'
				),
				// private
				'private' => array(
					'name' => __( 'Private', 'tp' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Private note text', 'tp' ),
					'desc' => __( 'Private note for post authors', 'tp' ),
					'icon' => 'lock'
				),
				// youtube
				'youtube' => array(
					'name' => __( 'YouTube', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'tp' ),
							'desc' => __( 'Url of YouTube page with video. Ex: http://youtube.com/watch?v=XXXXXX', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Player width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Player height', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'tp' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Play video automatically when page is loaded', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'YouTube video', 'tp' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// youtube_advanced
				'youtube_advanced' => array(
					'name' => __( 'YouTube Advanced', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'tp' ),
							'desc' => __( 'Url of YouTube page with video. Ex: http://youtube.com/watch?v=XXXXXX', 'tp' )
						),
						'playlist' => array(
							'default' => '',
							'name' => __( 'Playlist', 'tp' ),
							'desc' => __( 'Value is a comma-separated list of video IDs to play. If you specify a value, the first video that plays will be the VIDEO_ID specified in the URL path, and the videos specified in the playlist parameter will play thereafter', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Player width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Player height', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'tp' )
						),
						'controls' => array(
							'type' => 'select',
							'values' => array(
								'no' => __( '0 - Hide controls', 'tp' ),
								'yes' => __( '1 - Show controls', 'tp' ),
								'alt' => __( '2 - Show controls when playback is started', 'tp' )
							),
							'default' => 'yes',
							'name' => __( 'Controls', 'tp' ),
							'desc' => __( 'This parameter indicates whether the video player controls will display', 'tp' )
						),
						'autohide' => array(
							'type' => 'select',
							'values' => array(
								'no' => __( '0 - Do not hide controls', 'tp' ),
								'yes' => __( '1 - Hide all controls on mouse out', 'tp' ),
								'alt' => __( '2 - Hide progress bar on mouse out', 'tp' )
							),
							'default' => 'alt',
							'name' => __( 'Autohide', 'tp' ),
							'desc' => __( 'This parameter indicates whether the video controls will automatically hide after a video begins playing', 'tp' )
						),
						'showinfo' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show title bar', 'tp' ),
							'desc' => __( 'If you set the parameter value to NO, then the player will not display information like the video title and uploader before the video starts playing.', 'tp' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Play video automatically when page is loaded', 'tp' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'tp' ),
							'desc' => __( 'Setting of YES will cause the player to play the initial video again and again', 'tp' )
						),
						'rel' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Related videos', 'tp' ),
							'desc' => __( 'This parameter indicates whether the player should show related videos when playback of the initial video ends', 'tp' )
						),
						'fs' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show full-screen button', 'tp' ),
							'desc' => __( 'Setting this parameter to NO prevents the fullscreen button from displaying', 'tp' )
						),
						'modestbranding' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => 'modestbranding',
							'desc' => __( 'This parameter lets you use a YouTube player that does not show a YouTube logo. Set the parameter value to YES to prevent the YouTube logo from displaying in the control bar. Note that a small YouTube text label will still display in the upper-right corner of a paused video when the user\'s mouse pointer hovers over the player', 'tp' )
						),
						'theme' => array(
							'type' => 'select',
							'values' => array(
								'dark' => __( 'Dark theme', 'tp' ),
								'light' => __( 'Light theme', 'tp' )
							),
							'default' => 'dark',
							'name' => __( 'Theme', 'tp' ),
							'desc' => __( 'This parameter indicates whether the embedded player will display player controls (like a play button or volume control) within a dark or light control bar', 'tp' )
						),
						'https' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Force HTTPS', 'tp' ),
							'desc' => __( 'Use HTTPS in player iframe', 'tp' )
						),
						'wmode' => array(
							'default' => '',
							'name'    => __( 'WMode', 'tp' ),
							'desc'    => sprintf( __( 'Here you can specify wmode value for the embed URL. %s Example values: %s, %s', 'tp' ), '<br>', '<b%value>transparent</b>', '<b%value>opaque</b>' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'YouTube video player with advanced settings', 'tp' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// vimeo
				'vimeo' => array(
					'name' => __( 'Vimeo', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'tp' ), 'desc' => __( 'Url of Vimeo page with video', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Player width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Player height', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'tp' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Play video automatically when page is loaded', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Vimeo video', 'tp' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// screenr
				'screenr' => array(
					'name' => __( 'Screenr', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'default' => '',
							'name' => __( 'Url', 'tp' ),
							'desc' => __( 'Url of Screenr page with video', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Player width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Player height', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Screenr video', 'tp' ),
					'icon' => 'youtube-play'
				),
				// dailymotion
				'dailymotion' => array(
					'name' => __( 'Dailymotion', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'default' => '',
							'name' => __( 'Url', 'tp' ),
							'desc' => __( 'Url of Dailymotion page with video', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Player width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Player height', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'tp' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Start the playback of the video automatically after the player load. May not work on some mobile OS versions', 'tp' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#FFC300',
							'name' => __( 'Background color', 'tp' ),
							'desc' => __( 'HTML color of the background of controls elements', 'tp' )
						),
						'foreground' => array(
							'type' => 'color',
							'default' => '#F7FFFD',
							'name' => __( 'Foreground color', 'tp' ),
							'desc' => __( 'HTML color of the foreground of controls elements', 'tp' )
						),
						'highlight' => array(
							'type' => 'color',
							'default' => '#171D1B',
							'name' => __( 'Highlight color', 'tp' ),
							'desc' => __( 'HTML color of the controls elements\' highlights', 'tp' )
						),
						'logo' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show logo', 'tp' ),
							'desc' => __( 'Allows to hide or show the Dailymotion logo', 'tp' )
						),
						'quality' => array(
							'type' => 'select',
							'values' => array(
								'240'  => '240',
								'380'  => '380',
								'480'  => '480',
								'720'  => '720',
								'1080' => '1080'
							),
							'default' => '380',
							'name' => __( 'Quality', 'tp' ),
							'desc' => __( 'Determines the quality that must be played by default if available', 'tp' )
						),
						'related' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show related videos', 'tp' ),
							'desc' => __( 'Show related videos at the end of the video', 'tp' )
						),
						'info' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show video info', 'tp' ),
							'desc' => __( 'Show videos info (title/author) on the start screen', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Dailymotion video', 'tp' ),
					'icon' => 'youtube-play'
				),
				// audio
				'audio' => array(
					'name' => __( 'Audio', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'tp' ),
							'desc' => __( 'Audio file url. Supported formats: mp3, ogg', 'tp' )
						),
						'width' => array(
							'values' => array(),
							'default' => '100%',
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Player width. You can specify width in percents and player will be responsive. Example values: <b%value>200px</b>, <b%value>100&#37;</b>', 'tp' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Play file automatically when page is loaded', 'tp' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'tp' ),
							'desc' => __( 'Repeat when playback is ended', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Custom audio player', 'tp' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// video
				'video' => array(
					'name' => __( 'Video', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'tp' ),
							'desc' => __( 'Url to mp4/flv video-file', 'tp' )
						),
						'poster' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Poster', 'tp' ),
							'desc' => __( 'Url to poster image, that will be shown before playback', 'tp' )
						),
						'title' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Title', 'tp' ),
							'desc' => __( 'Player title', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Player width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 300,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Player height', 'tp' )
						),
						'controls' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Controls', 'tp' ),
							'desc' => __( 'Show player controls (play/pause etc.) or not', 'tp' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Play file automatically when page is loaded', 'tp' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'tp' ),
							'desc' => __( 'Repeat when playback is ended', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Custom video player', 'tp' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// table
				'table' => array(
					'name' => __( 'Table', 'tp' ),
					'type' => 'mixed',
					'group' => 'content',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'CSV file', 'tp' ),
							'desc' => __( 'Upload CSV file if you want to create HTML-table from file', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( "<table>\n<tr>\n\t<td>Table</td>\n\t<td>Table</td>\n</tr>\n<tr>\n\t<td>Table</td>\n\t<td>Table</td>\n</tr>\n</table>", 'tp' ),
					'desc' => __( 'Styled table from HTML or CSV file', 'tp' ),
					'icon' => 'table'
				),
				// permalink
				'permalink' => array(
					'name' => __( 'Permalink', 'tp' ),
					'type' => 'mixed',
					'group' => 'content other',
					'atts' => array(
						'id' => array(
							'values' => array( ), 'default' => 1,
							'name' => __( 'ID', 'tp' ),
							'desc' => __( 'Post or page ID', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same tab', 'tp' ),
								'blank' => __( 'New tab', 'tp' )
							),
							'default' => 'self',
							'name' => __( 'Target', 'tp' ),
							'desc' => __( 'Link target. blank - link will be opened in new window/tab', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => '',
					'desc' => __( 'Permalink to specified post/page', 'tp' ),
					'icon' => 'link'
				),
				// members
				'members' => array(
					'name' => __( 'Members', 'tp' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'message' => array(
							'default' => __( 'This content is for registered users only. Please %login%.', 'tp' ),
							'name' => __( 'Message', 'tp' ), 'desc' => __( 'Message for not logged users', 'tp' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#ffcc00',
							'name' => __( 'Box color', 'tp' ), 'desc' => __( 'This color will applied only to box for not logged users', 'tp' )
						),
						'login_text' => array(
							'default' => __( 'login', 'tp' ),
							'name' => __( 'Login link text', 'tp' ), 'desc' => __( 'Text for the login link', 'tp' )
						),
						'login_url' => array(
							'default' => wp_login_url(),
							'name' => __( 'Login link url', 'tp' ), 'desc' => __( 'Login link url', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Content for logged members', 'tp' ),
					'desc' => __( 'Content for logged in members only', 'tp' ),
					'icon' => 'lock'
				),
				// guests
				'guests' => array(
					'name' => __( 'Guests', 'tp' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Content for guests', 'tp' ),
					'desc' => __( 'Content for guests only', 'tp' ),
					'icon' => 'user'
				),
				// feed
				'feed' => array(
					'name' => __( 'RSS Feed', 'tp' ),
					'type' => 'single',
					'group' => 'content other',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'tp' ),
							'desc' => __( 'Url to RSS-feed', 'tp' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Limit', 'tp' ), 'desc' => __( 'Number of items to show', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Feed grabber', 'tp' ),
					'icon' => 'rss'
				),
				// menu
				'menu' => array(
					'name' => __( 'Menu', 'tp' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'name' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Menu name', 'tp' ), 'desc' => __( 'Custom menu name. Ex: Main menu', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Custom menu by name', 'tp' ),
					'icon' => 'bars'
				),
				// subpages
				'subpages' => array(
					'name' => __( 'Sub pages', 'tp' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'depth' => array(
							'type' => 'select',
							'values' => array( 1, 2, 3, 4, 5 ), 'default' => 1,
							'name' => __( 'Depth', 'tp' ),
							'desc' => __( 'Max depth level of children pages', 'tp' )
						),
						'p' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Parent ID', 'tp' ),
							'desc' => __( 'ID of the parent page. Leave blank to use current page', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'List of sub pages', 'tp' ),
					'icon' => 'bars'
				),
				// siblings
				'siblings' => array(
					'name' => __( 'Siblings', 'tp' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'depth' => array(
							'type' => 'select',
							'values' => array( 1, 2, 3 ), 'default' => 1,
							'name' => __( 'Depth', 'tp' ),
							'desc' => __( 'Max depth level', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'List of cureent page siblings', 'tp' ),
					'icon' => 'bars'
				),
				// document
				'document' => array(
					'name' => __( 'Document', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Url', 'tp' ),
							'desc' => __( 'Url to uploaded document. Supported formats: doc, xls, pdf etc.', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Viewer width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Viewer height', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make viewer responsive', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Document viewer by Google', 'tp' ),
					'icon' => 'file-text'
				),
				// gmap
				'gmap' => array(
					'name' => __( 'Gmap', 'tp' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Map width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Map height', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make map responsive', 'tp' )
						),
						'address' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Marker', 'tp' ),
							'desc' => __( 'Address for the marker. You can type it in any language', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Maps by Google', 'tp' ),
					'icon' => 'globe'
				),
				// slider
				'slider' => array(
					'name' => __( 'Slider', 'tp' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'tp' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'tp' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'tp' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'tp' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'tp' ),
								'image'      => __( 'Full-size image', 'tp' ),
								'lightbox'   => __( 'Lightbox', 'tp' ),
								'custom'     => __( 'Slide link (added in media editor)', 'tp' ),
								'attachment' => __( 'Attachment page', 'tp' ),
								'post'       => __( 'Post permalink', 'tp' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'tp' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'tp' ),
								'blank' => __( 'New window', 'tp' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'tp' ),
							'desc' => __( 'Open links in', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ), 'desc' => __( 'Slider width (in pixels)', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 300,
							'name' => __( 'Height', 'tp' ), 'desc' => __( 'Slider height (in pixels)', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make slider responsive', 'tp' )
						),
						'title' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show titles', 'tp' ), 'desc' => __( 'Display slide titles', 'tp' )
						),
						'centered' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Center', 'tp' ), 'desc' => __( 'Is slider centered on the page', 'tp' )
						),
						'arrows' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Arrows', 'tp' ), 'desc' => __( 'Show left and right arrows', 'tp' )
						),
						'pages' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Pagination', 'tp' ),
							'desc' => __( 'Show pagination', 'tp' )
						),
						'mousewheel' => array(
							'type' => 'bool',
							'default' => 'yes', 'name' => __( 'Mouse wheel control', 'tp' ),
							'desc' => __( 'Allow to change slides with mouse wheel', 'tp' )
						),
						'autoplay' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 100000,
							'step' => 100,
							'default' => 5000,
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Choose interval between slide animations. Set to 0 to disable autoplay', 'tp' )
						),
						'speed' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 20000,
							'step' => 100,
							'default' => 600,
							'name' => __( 'Speed', 'tp' ), 'desc' => __( 'Specify animation speed', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Customizable image slider', 'tp' ),
					'icon' => 'picture-o'
				),
				// carousel
				'carousel' => array(
					'name' => __( 'Carousel', 'tp' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'tp' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'tp' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'tp' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'tp' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'tp' ),
								'image'      => __( 'Full-size image', 'tp' ),
								'lightbox'   => __( 'Lightbox', 'tp' ),
								'custom'     => __( 'Slide link (added in media editor)', 'tp' ),
								'attachment' => __( 'Attachment page', 'tp' ),
								'post'       => __( 'Post permalink', 'tp' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'tp' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'tp' ),
								'blank' => __( 'New window', 'tp' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'tp' ),
							'desc' => __( 'Open links in', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 100,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Carousel width (in pixels)', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 20,
							'max' => 1600,
							'step' => 20,
							'default' => 100,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Carousel height (in pixels)', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make carousel responsive', 'tp' )
						),
						'items' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Items to show', 'tp' ),
							'desc' => __( 'How much carousel items is visible', 'tp' )
						),
						'scroll' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1, 'default' => 1,
							'name' => __( 'Scroll number', 'tp' ),
							'desc' => __( 'How much items are scrolled in one transition', 'tp' )
						),
						'title' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show titles', 'tp' ), 'desc' => __( 'Display titles for each item', 'tp' )
						),
						'centered' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Center', 'tp' ), 'desc' => __( 'Is carousel centered on the page', 'tp' )
						),
						'arrows' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Arrows', 'tp' ), 'desc' => __( 'Show left and right arrows', 'tp' )
						),
						'pages' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Pagination', 'tp' ),
							'desc' => __( 'Show pagination', 'tp' )
						),
						'mousewheel' => array(
							'type' => 'bool',
							'default' => 'yes', 'name' => __( 'Mouse wheel control', 'tp' ),
							'desc' => __( 'Allow to rotate carousel with mouse wheel', 'tp' )
						),
						'autoplay' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 100000,
							'step' => 100,
							'default' => 5000,
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Choose interval between auto animations. Set to 0 to disable autoplay', 'tp' )
						),
						'speed' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 20000,
							'step' => 100,
							'default' => 600,
							'name' => __( 'Speed', 'tp' ), 'desc' => __( 'Specify animation speed', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Customizable image carousel', 'tp' ),
					'icon' => 'picture-o'
				),
				// carousel
				'posts_carousel' => array(
					'name' => __( 'Posts Carousel', 'tp' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 10,
							'name' => __( 'Limit', 'tp' ),
							'desc' => __( 'Maximum number of image source posts', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'tp' ),
								'blank' => __( 'New window', 'tp' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'tp' ),
							'desc' => __( 'Open links in', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 100,
							'max' => 1600,
							'step' => 5,
							'default' => 285,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Carousel width (in pixels)', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 20,
							'max' => 1600,
							'step' => 5,
							'default' => 190,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Carousel height (in pixels)', 'tp' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'tp' ),
							'desc' => __( 'Ignore width and height parameters and make carousel responsive', 'tp' )
						),
						'items' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 4,
							'name' => __( 'Items to show', 'tp' ),
							'desc' => __( 'How much carousel items is visible', 'tp' )
						),
						'scroll' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1, 'default' => 1,
							'name' => __( 'Scroll number', 'tp' ),
							'desc' => __( 'How much items are scrolled in one transition', 'tp' )
						),
						'title' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show titles', 'tp' ), 'desc' => __( 'Display titles for each item', 'tp' )
						),
						'centered' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Center', 'tp' ), 'desc' => __( 'Is carousel centered on the page', 'tp' )
						),
						'arrows' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Arrows', 'tp' ), 'desc' => __( 'Show left and right arrows', 'tp' )
						),
						'pages' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Pagination', 'tp' ),
							'desc' => __( 'Show pagination', 'tp' )
						),
						'mousewheel' => array(
							'type' => 'bool',
							'default' => 'no', 'name' => __( 'Mouse wheel control', 'tp' ),
							'desc' => __( 'Allow to rotate carousel with mouse wheel', 'tp' )
						),
						'autoplay' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 100000,
							'step' => 100,
							'default' => 5000,
							'name' => __( 'Autoplay', 'tp' ),
							'desc' => __( 'Choose interval between auto animations. Set to 0 to disable autoplay', 'tp' )
						),
						'speed' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 20000,
							'step' => 100,
							'default' => 600,
							'name' => __( 'Speed', 'tp' ), 'desc' => __( 'Specify animation speed', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Customizable image carousel', 'tp' ),
					'icon' => 'picture-o'
				),
				// custom_gallery
				'custom_gallery' => array(
					'name' => __( 'Gallery', 'tp' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'tp' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'tp' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'tp' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'tp' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'tp' ),
								'image'      => __( 'Full-size image', 'tp' ),
								'lightbox'   => __( 'Lightbox', 'tp' ),
								'custom'     => __( 'Slide link (added in media editor)', 'tp' ),
								'attachment' => __( 'Attachment page', 'tp' ),
								'post'       => __( 'Post permalink', 'tp' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'tp' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'tp' ),
								'blank' => __( 'New window', 'tp' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'tp' ),
							'desc' => __( 'Open links in', 'tp' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 90,
							'name' => __( 'Width', 'tp' ), 'desc' => __( 'Single item width (in pixels)', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 90,
							'name' => __( 'Height', 'tp' ), 'desc' => __( 'Single item height (in pixels)', 'tp' )
						),
						'title' => array(
							'type' => 'select',
							'values' => array(
								'never' => __( 'Never', 'tp' ),
								'hover' => __( 'On mouse over', 'tp' ),
								'always' => __( 'Always', 'tp' )
							),
							'default' => 'hover',
							'name' => __( 'Show titles', 'tp' ),
							'desc' => __( 'Title display mode', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Customizable image gallery', 'tp' ),
					'icon' => 'picture-o'
				),
				// posts
				'posts' => array(
					'name' => __( 'Posts', 'tp' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'template' => array(
							'default' => 'templates/default-loop.php', 'name' => __( 'Template', 'tp' ),
							'desc' => __( '<b>Do not change this field value if you do not understand description below.</b><br/>Relative path to the template file. Default templates is placed under the plugin directory (templates folder). You can copy it under your theme directory and modify as you want. You can use following default templates that already available in the plugin directory:<br/><b%value>templates/default-loop.php</b> - posts loop<br/><b%value>templates/teaser-loop.php</b> - posts loop with thumbnail and title<br/><b%value>templates/single-post.php</b> - single post template<br/><b%value>templates/list-loop.php</b> - unordered list with posts titles', 'tp' )
						),
						'id' => array(
							'default' => '',
							'name' => __( 'Post ID\'s', 'tp' ),
							'desc' => __( 'Enter comma separated ID\'s of the posts that you want to show', 'tp' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Posts per page', 'tp' ),
							'desc' => __( 'Specify number of posts that you want to show. Enter -1 to get all posts', 'tp' )
						),
						'post_type' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Tp_Tools::get_types(),
							'default' => 'post',
							'name' => __( 'Post types', 'tp' ),
							'desc' => __( 'Select post types. Hold Ctrl key to select multiple post types', 'tp' )
						),
						'taxonomy' => array(
							'type' => 'select',
							'values' => Tp_Tools::get_taxonomies(),
							'default' => 'category',
							'name' => __( 'Taxonomy', 'tp' ),
							'desc' => __( 'Select taxonomy to show posts from', 'tp' )
						),
						'tax_term' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Tp_Tools::get_terms( 'category' ),
							'default' => '',
							'name' => __( 'Terms', 'tp' ),
							'desc' => __( 'Select terms to show posts from', 'tp' )
						),
						'tax_operator' => array(
							'type' => 'select',
							'values' => array( 'IN', 'NOT IN', 'AND' ),
							'default' => 'IN', 'name' => __( 'Taxonomy term operator', 'tp' ),
							'desc' => __( 'IN - posts that have any of selected categories terms<br/>NOT IN - posts that is does not have any of selected terms<br/>AND - posts that have all selected terms', 'tp' )
						),
						// 'author' => array(
						// 	'type' => 'select',
						// 	'multiple' => true,
						// 	'values' => Tp_Tools::get_users(),
						// 	'default' => 'default',
						// 	'name' => __( 'Authors', 'tp' ),
						// 	'desc' => __( 'Choose the authors whose posts you want to show. Enter here comma-separated list of users (IDs). Example: 1,7,18', 'tp' )
						// ),
						'author' => array(
							'default' => '',
							'name' => __( 'Authors', 'tp' ),
							'desc' => __( 'Enter here comma-separated list of author\'s IDs. Example: 1,7,18', 'tp' )
						),
						'meta_key' => array(
							'default' => '',
							'name' => __( 'Meta key', 'tp' ),
							'desc' => __( 'Enter meta key name to show posts that have this key', 'tp' )
						),
						'offset' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 10000,
							'step' => 1, 'default' => 0,
							'name' => __( 'Offset', 'tp' ),
							'desc' => __( 'Specify offset to start posts loop not from first post', 'tp' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'tp' ),
								'asc' => __( 'Ascending', 'tp' )
							),
							'default' => 'DESC',
							'name' => __( 'Order', 'tp' ),
							'desc' => __( 'Posts order', 'tp' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'tp' ),
								'id' => __( 'Post ID', 'tp' ),
								'author' => __( 'Post author', 'tp' ),
								'title' => __( 'Post title', 'tp' ),
								'name' => __( 'Post slug', 'tp' ),
								'date' => __( 'Date', 'tp' ), 'modified' => __( 'Last modified date', 'tp' ),
								'parent' => __( 'Post parent', 'tp' ),
								'rand' => __( 'Random', 'tp' ), 'comment_count' => __( 'Comments number', 'tp' ),
								'menu_order' => __( 'Menu order', 'tp' ), 'meta_value' => __( 'Meta key values', 'tp' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'tp' ),
							'desc' => __( 'Order posts by', 'tp' )
						),
						'post_parent' => array(
							'default' => '',
							'name' => __( 'Post parent', 'tp' ),
							'desc' => __( 'Show childrens of entered post (enter post ID)', 'tp' )
						),
						'post_status' => array(
							'type' => 'select',
							'values' => array(
								'publish' => __( 'Published', 'tp' ),
								'pending' => __( 'Pending', 'tp' ),
								'draft' => __( 'Draft', 'tp' ),
								'auto-draft' => __( 'Auto-draft', 'tp' ),
								'future' => __( 'Future post', 'tp' ),
								'private' => __( 'Private post', 'tp' ),
								'inherit' => __( 'Inherit', 'tp' ),
								'trash' => __( 'Trashed', 'tp' ),
								'any' => __( 'Any', 'tp' ),
							),
							'default' => 'publish',
							'name' => __( 'Post status', 'tp' ),
							'desc' => __( 'Show only posts with selected status', 'tp' )
						),
						'ignore_sticky_posts' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Ignore sticky', 'tp' ),
							'desc' => __( 'Select Yes to ignore posts that is sticked', 'tp' )
						)
					),
					'desc' => __( 'Custom posts query with customizable template', 'tp' ),
					'icon' => 'th-list'
				),
				// dummy_text
				'dummy_text' => array(
					'name' => __( 'Dummy text', 'tp' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'what' => array(
							'type' => 'select',
							'values' => array(
								'paras' => __( 'Paragraphs', 'tp' ),
								'words' => __( 'Words', 'tp' ),
								'bytes' => __( 'Bytes', 'tp' ),
							),
							'default' => 'paras',
							'name' => __( 'What', 'tp' ),
							'desc' => __( 'What to generate', 'tp' )
						),
						'amount' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 1,
							'name' => __( 'Amount', 'tp' ),
							'desc' => __( 'How many items (paragraphs or words) to generate. Minimum words amount is 5', 'tp' )
						),
						'cache' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Cache', 'tp' ),
							'desc' => __( 'Generated text will be cached. Be careful with this option. If you disable it and insert many dummy_text shortcodes the page load time will be highly increased', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Text placeholder', 'tp' ),
					'icon' => 'text-height'
				),
				// dummy_image
				'dummy_image' => array(
					'name' => __( 'Dummy image', 'tp' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'width' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 500,
							'name' => __( 'Width', 'tp' ),
							'desc' => __( 'Image width', 'tp' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 300,
							'name' => __( 'Height', 'tp' ),
							'desc' => __( 'Image height', 'tp' )
						),
						'theme' => array(
							'type' => 'select',
							'values' => array(
								'any'       => __( 'Any', 'tp' ),
								'abstract'  => __( 'Abstract', 'tp' ),
								'animals'   => __( 'Animals', 'tp' ),
								'business'  => __( 'Business', 'tp' ),
								'cats'      => __( 'Cats', 'tp' ),
								'city'      => __( 'City', 'tp' ),
								'food'      => __( 'Food', 'tp' ),
								'nightlife' => __( 'Night life', 'tp' ),
								'fashion'   => __( 'Fashion', 'tp' ),
								'people'    => __( 'People', 'tp' ),
								'nature'    => __( 'Nature', 'tp' ),
								'sports'    => __( 'Sports', 'tp' ),
								'technics'  => __( 'Technics', 'tp' ),
								'transport' => __( 'Transport', 'tp' )
							),
							'default' => 'any',
							'name' => __( 'Theme', 'tp' ),
							'desc' => __( 'Select the theme for this image', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Image placeholder with random image', 'tp' ),
					'icon' => 'picture-o'
				),
				// animate
				'animate' => array(
					'name' => __( 'Animation', 'tp' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array_combine( self::animations(), self::animations() ),
							'default' => 'bounceIn',
							'name' => __( 'Animation', 'tp' ),
							'desc' => __( 'Select animation type', 'tp' )
						),
						'duration' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 0.5,
							'default' => 1,
							'name' => __( 'Duration', 'tp' ),
							'desc' => __( 'Animation duration (seconds)', 'tp' )
						),
						'delay' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 0.5,
							'default' => 0,
							'name' => __( 'Delay', 'tp' ),
							'desc' => __( 'Animation delay (seconds)', 'tp' )
						),
						'inline' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Inline', 'tp' ),
							'desc' => __( 'This parameter determines what HTML tag will be used for animation wrapper. Turn this option to YES and animated element will be wrapped in SPAN instead of DIV. Useful for inline animations, like buttons', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Animated content', 'tp' ),
					'desc' => __( 'Wrapper for animation. Any nested element will be animated', 'tp' ),
					'example' => 'animations',
					'icon' => 'bolt'
				),
				// meta
				'meta' => array(
					'name' => __( 'Meta', 'tp' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'key' => array(
							'default' => '',
							'name' => __( 'Key', 'tp' ),
							'desc' => __( 'Meta key name', 'tp' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'tp' ),
							'desc' => __( 'This text will be shown if data is not found', 'tp' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'tp' ),
							'desc' => __( 'This content will be shown before the value', 'tp' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'tp' ),
							'desc' => __( 'This content will be shown after the value', 'tp' )
						),
						'post_id' => array(
							'default' => '',
							'name' => __( 'Post ID', 'tp' ),
							'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'tp' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'tp' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'tp' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'Post meta', 'tp' ),
					'icon' => 'info-circle'
				),
				// user
				'user' => array(
					'name' => __( 'User', 'tp' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'field' => array(
							'type' => 'select',
							'values' => array(
								'display_name'        => __( 'Display name', 'tp' ),
								'ID'                  => __( 'ID', 'tp' ),
								'user_login'          => __( 'Login', 'tp' ),
								'user_nicename'       => __( 'Nice name', 'tp' ),
								'user_email'          => __( 'Email', 'tp' ),
								'user_url'            => __( 'URL', 'tp' ),
								'user_registered'     => __( 'Registered', 'tp' ),
								'user_activation_key' => __( 'Activation key', 'tp' ),
								'user_status'         => __( 'Status', 'tp' )
							),
							'default' => 'display_name',
							'name' => __( 'Field', 'tp' ),
							'desc' => __( 'User data field name', 'tp' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'tp' ),
							'desc' => __( 'This text will be shown if data is not found', 'tp' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'tp' ),
							'desc' => __( 'This content will be shown before the value', 'tp' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'tp' ),
							'desc' => __( 'This content will be shown after the value', 'tp' )
						),
						'user_id' => array(
							'default' => '',
							'name' => __( 'User ID', 'tp' ),
							'desc' => __( 'You can specify custom user ID. Leave this field empty to use an ID of the current user', 'tp' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'tp' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'tp' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'User data', 'tp' ),
					'icon' => 'info-circle'
				),
				// post
				'post' => array(
					'name' => __( 'Post', 'tp' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'field' => array(
							'type' => 'select',
							'values' => array(
								'ID'                    => __( 'Post ID', 'tp' ),
								'post_author'           => __( 'Post author', 'tp' ),
								'post_date'             => __( 'Post date', 'tp' ),
								'post_date_gmt'         => __( 'Post date', 'tp' ) . ' GMT',
								'post_content'          => __( 'Post content', 'tp' ),
								'post_title'            => __( 'Post title', 'tp' ),
								'post_excerpt'          => __( 'Post excerpt', 'tp' ),
								'post_status'           => __( 'Post status', 'tp' ),
								'comment_status'        => __( 'Comment status', 'tp' ),
								'ping_status'           => __( 'Ping status', 'tp' ),
								'post_name'             => __( 'Post name', 'tp' ),
								'post_modified'         => __( 'Post modified', 'tp' ),
								'post_modified_gmt'     => __( 'Post modified', 'tp' ) . ' GMT',
								'post_content_filtered' => __( 'Filtered post content', 'tp' ),
								'post_parent'           => __( 'Post parent', 'tp' ),
								'guid'                  => __( 'GUID', 'tp' ),
								'menu_order'            => __( 'Menu order', 'tp' ),
								'post_type'             => __( 'Post type', 'tp' ),
								'post_mime_type'        => __( 'Post mime type', 'tp' ),
								'comment_count'         => __( 'Comment count', 'tp' )
							),
							'default' => 'post_title',
							'name' => __( 'Field', 'tp' ),
							'desc' => __( 'Post data field name', 'tp' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'tp' ),
							'desc' => __( 'This text will be shown if data is not found', 'tp' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'tp' ),
							'desc' => __( 'This content will be shown before the value', 'tp' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'tp' ),
							'desc' => __( 'This content will be shown after the value', 'tp' )
						),
						'post_id' => array(
							'default' => '',
							'name' => __( 'Post ID', 'tp' ),
							'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'tp' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'tp' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'tp' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'Post data', 'tp' ),
					'icon' => 'info-circle'
				),
				// post_terms
				// 'post_terms' => array(
				// 	'name' => __( 'Post terms', 'tp' ),
				// 	'type' => 'single',
				// 	'group' => 'data',
				// 	'atts' => array(
				// 		'post_id' => array(
				// 			'default' => '',
				// 			'name' => __( 'Post ID', 'tp' ),
				// 			'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'tp' )
				// 		),
				// 		'links' => array(
				// 			'type' => 'bool',
				// 			'default' => 'yes',
				// 			'name' => __( 'Show links', 'tp' ),
				// 			'desc' => __( 'Show terms names as hyperlinks', 'tp' )
				// 		),
				// 		'format' => array(
				// 			'type' => 'select',
				// 			'values' => array(
				// 				'text' => __( 'Terms separated by commas', 'tp' ),
				// 				'br' => __( 'Terms separated by new lines', 'tp' ),
				// 				'ul' => __( 'Unordered list', 'tp' ),
				// 				'ol' => __( 'Ordered list', 'tp' ),
				// 			),
				// 			'default' => 'text',
				// 			'name' => __( 'Format', 'tp' ),
				// 			'desc' => __( 'Choose how to output the terms', 'tp' )
				// 		),
				// 	),
				// 	'desc' => __( 'Terms list', 'tp' ),
				// 	'icon' => 'info-circle'
				// ),
				// template
				'template' => array(
					'name' => __( 'Template', 'tp' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'name' => array(
							'default' => '',
							'name' => __( 'Template name', 'tp' ),
							'desc' => sprintf( __( 'Use template file name (with optional .php extension). If you need to use templates from theme sub-folder, use relative path. Example values: %s, %s, %s', 'tp' ), '<b%value>page</b>', '<b%value>page.php</b>', '<b%value>includes/page.php</b>' )
						)
					),
					'desc' => __( 'Theme template', 'tp' ),
					'icon' => 'puzzle-piece'
				),
				// qrcode
				'qrcode' => array(
					'name' => __( 'QR code', 'tp' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'data' => array(
							'default' => '',
							'name' => __( 'Data', 'tp' ),
							'desc' => __( 'The text to store within the QR code. You can use here any text or even URL', 'tp' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Title', 'tp' ),
							'desc' => __( 'Enter here short description. This text will be used in alt attribute of QR code', 'tp' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1000,
							'step' => 10,
							'default' => 200,
							'name' => __( 'Size', 'tp' ),
							'desc' => __( 'Image width and height (in pixels)', 'tp' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 50,
							'step' => 5,
							'default' => 0,
							'name' => __( 'Margin', 'tp' ),
							'desc' => __( 'Thickness of a margin (in pixels)', 'tp' )
						),
						'align' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'tp' ),
								'left' => __( 'Left', 'tp' ),
								'center' => __( 'Center', 'tp' ),
								'right' => __( 'Right', 'tp' ),
							),
							'default' => 'none',
							'name' => __( 'Align', 'tp' ),
							'desc' => __( 'Choose image alignment', 'tp' )
						),
						'link' => array(
							'default' => '',
							'name' => __( 'Link', 'tp' ),
							'desc' => __( 'You can make this QR code clickable. Enter here the URL', 'tp' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Open link in same window/tab', 'tp' ),
								'blank' => __( 'Open link in new window/tab', 'tp' ),
							),
							'default' => 'blank',
							'name' => __( 'Link target', 'tp' ),
							'desc' => __( 'Select link target', 'tp' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#000000',
							'name' => __( 'Primary color', 'tp' ),
							'desc' => __( 'Pick a primary color', 'tp' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Background color', 'tp' ),
							'desc' => __( 'Pick a background color', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( 'Advanced QR code generator', 'tp' ),
					'icon' => 'qrcode'
				),
				// scheduler
				'scheduler' => array(
					'name' => __( 'Scheduler', 'tp' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'time' => array(
							'default' => '',
							'name' => __( 'Time', 'tp' ),
							'desc' => sprintf( __( 'In this field you can specify one or more time ranges. Every day at this time the content of shortcode will be visible. %s %s %s - show content from 9:00 to 18:00 %s - show content from 9:00 to 13:00 and from 14:00 to 18:00 %s - example with minutes (content will be visible each day, 45 minutes) %s - example with seconds', 'tp' ), '<br><br>', __( 'Examples (click to set)', 'tp' ), '<br><b%value>9-18</b>', '<br><b%value>9-13, 14-18</b>', '<br><b%value>9:30-10:15</b>', '<br><b%value>9:00:00-17:59:59</b>' )
						),
						'days_week' => array(
							'default' => '',
							'name' => __( 'Days of the week', 'tp' ),
							'desc' => sprintf( __( 'In this field you can specify one or more days of the week. Every week at these days the content of shortcode will be visible. %s 0 - Sunday %s 1 - Monday %s 2 - Tuesday %s 3 - Wednesday %s 4 - Thursday %s 5 - Friday %s 6 - Saturday %s %s %s - show content from Monday to Friday %s - show content only at Sunday %s - show content at Sunday and from Wednesday to Friday', 'tp' ), '<br><br>', '<br>', '<br>', '<br>', '<br>', '<br>', '<br>', '<br><br>', __( 'Examples (click to set)', 'tp' ), '<br><b%value>1-5</b>', '<br><b%value>0</b>', '<br><b%value>0, 3-5</b>' )
						),
						'days_month' => array(
							'default' => '',
							'name' => __( 'Days of the month', 'tp' ),
							'desc' => sprintf( __( 'In this field you can specify one or more days of the month. Every month at these days the content of shortcode will be visible. %s %s %s - show content only at first day of month %s - show content from 1th to 5th %s - show content from 10th to 15th and from 20th to 25th', 'tp' ), '<br><br>', __( 'Examples (click to set)', 'tp' ), '<br><b%value>1</b>', '<br><b%value>1-5</b>', '<br><b%value>10-15, 20-25</b>' )
						),
						'months' => array(
							'default' => '',
							'name' => __( 'Months', 'tp' ),
							'desc' => sprintf( __( 'In this field you can specify the month or months in which the content will be visible. %s %s %s - show content only in January %s - show content from February to June %s - show content in January, March and from May to July', 'tp' ), '<br><br>', __( 'Examples (click to set)', 'tp' ), '<br><b%value>1</b>', '<br><b%value>2-6</b>', '<br><b%value>1, 3, 5-7</b>' )
						),
						'years' => array(
							'default' => '',
							'name' => __( 'Years', 'tp' ),
							'desc' => sprintf( __( 'In this field you can specify the year or years in which the content will be visible. %s %s %s - show content only in 2014 %s - show content from 2014 to 2016 %s - show content in 2014, 2018 and from 2020 to 2022', 'tp' ), '<br><br>', __( 'Examples (click to set)', 'tp' ), '<br><b%value>2014</b>', '<br><b%value>2014-2016</b>', '<br><b%value>2014, 2018, 2020-2022</b>' )
						),
						'alt' => array(
							'default' => '',
							'name' => __( 'Alternative text', 'tp' ),
							'desc' => __( 'In this field you can type the text which will be shown if content is not visible at the current moment', 'tp' )
						)
					),
					'content' => __( 'Scheduled content', 'tp' ),
					'desc' => __( 'Allows to show the content only at the specified time period', 'tp' ),
					'note' => __( 'This shortcode allows you to show content only at the specified time.', 'tp' ) . '<br><br>' . __( 'Please pay special attention to the descriptions, which are located below each text field. It will save you a lot of time', 'tp' ) . '<br><br>' . __( 'By default, the content of this shortcode will be visible all the time. By using fields below, you can add some limitations. For example, if you type 1-5 in the Days of the week field, content will be only shown from Monday to Friday. Using the same principles, you can limit content visibility from years to seconds.', 'tp' ),
					'icon' => 'clock-o'
				),
			) );

			//counter up
			$shortcodes['counterup'] = 
				array(
					'name' => __( 'Counter up', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'number' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100000,
							'step' => 1,
							'default' => 1000,
							'name' => __( 'Total number', 'tp' ),
							'desc' => __( 'This is count up from zero.', 'tp' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'tp' ),
							'desc' => __( 'You can upload custom icon for this box', 'tp' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#c13832',
							'name' => __( 'Icon color', 'tp' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'tp' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 128,
							'step' => 1,
							'default' => 50,
							'name' => __( 'Icon size', 'tp' ),
							'desc' => __( 'Size of the uploaded icon in pixels', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'counter description', 'tp' ),
					'desc' => __( '', 'tp' ),
					'icon' => 'check-square-o'
				);
			
			//skill bar
			$shortcodes['skillbar'] = 
				array(
					'name' => __( 'Skill bar', 'tp' ),
					'type' => 'single',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'default' => 'Wordpress',
							'name' => __( 'Title', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'percent' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 80,
							'name' => __( 'Total percentage', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#f9f9f9',
							'name' => __( 'Bacground color', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'activebackground' => array(
							'type' => 'color',
							'default' => '#000',
							'name' => __( 'Active Bacground color', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'desc' => __( '', 'tp' ),
					'icon' => 'bar-chart-o'
				);

			//Testimonial group
			$shortcodes['testimonials'] = 
				array(
					'name' => __( 'Testimonials', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						
					),
					'content' => __( 'Single testimonial shortcode goes here', 'tp' ),
					'desc' => __( '', 'tp' ),
					'icon' => 'recycle'
				);

			//Testimonial bar
			$shortcodes['testimonial'] = 
				array(
					'name' => __( 'Testimonial', 'tp' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'name' => array(
							'type' => 'text',
							'default' => 'Jhon',
							'name' => __( 'Name', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'title' => array(
							'type' => 'text',
							'default' => 'CEO, Themeperch',
							'name' => __( 'Title', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'website' => array(
							'type' => 'text',
							'default' => 'http://themeperch.com',
							'name' => __( 'Website', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'image' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Upload Photo', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'tp' ),
							'desc' => __( 'Extra CSS class', 'tp' )
						)
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'tp' ),
					'desc' => __( '', 'tp' ),
					'icon' => 'quote-left'
				);	

			
			$pc = $cc = 4;
			if(function_exists('ot_get_option')) $pc = ot_get_option( 'product_column', 4 );
			

			$shortcodes['product'] = 
				array(
					'name' => __( 'Product', 'tp' ),
					'type' => 'single',
					'group' => 'product',
					'atts' => array(
							'id' => array(
								'type' => 'select',
								'values' => Tp_Tools::get_posts_dropdown( array('post_type'=> 'product', 'posts_per_page' => -1) ),
								'default' => '',
								'name' => __( 'Product lists', 'tp' ),
								'desc' => 'Select a product'
							),
						
						),
					'desc' => __( 'Product', 'tp' ),
					'icon' => 'file-o'
				);

			//products	
			$shortcodes['products'] = 
				array(
					'name' => __( 'Products', 'tp' ),
					'type' => 'single',
					'group' => 'product',
					'atts' => array(
						'ids' => array(
							'type' => 'select',
							'values' => Tp_Tools::get_posts_dropdown( array('post_type'=> 'product', 'posts_per_page' => -1) ),
							'default' => '',
							'multiple' => 'multiple',
							'name' => __( 'Product lists', 'tp' ),
							'desc' => 'Select a product'
						),
						'per_page' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 50,
							'step' => 1,
							'default' => 12,
							'name' => __( 'Per page', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'columns' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 4,
							'step' => 1,
							'default' => $pc,
							'name' => __( 'Columns', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'tp' ),
								'id' => __( 'Post ID', 'tp' ),
								'author' => __( 'Post author', 'tp' ),
								'title' => __( 'Post title', 'tp' ),
								'name' => __( 'Post slug', 'tp' ),
								'date' => __( 'Date', 'tp' ), 'modified' => __( 'Last modified date', 'tp' ),
								'parent' => __( 'Post parent', 'tp' ),
								'rand' => __( 'Random', 'tp' ), 'comment_count' => __( 'Comments number', 'tp' ),
								'menu_order' => __( 'Menu order', 'tp' ), 'meta_value' => __( 'Meta key values', 'tp' ),
							),
							'default' => 'title',
							'name' => __( 'Order by', 'tp' ),
							'desc' => __( 'Order posts by', 'tp' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'tp' ),
								'asc' => __( 'Ascending', 'tp' )
							),
							'default' => 'asc',
							'name' => __( 'Order', 'tp' ),
							'desc' => __( 'Posts order', 'tp' )
						),
					),
					'desc' => __( 'Multiple Product', 'tp' ),
					'icon' => 'files-o'
				);	

			//Product category 
			$shortcodes['product_category'] = 
				array(
					'name' => __( 'Product category', 'tp' ),
					'type' => 'single',
					'group' => 'product',
					'atts' => array(
						'taxonomy' => array(
							'type' => 'select',
							'values' => Tp_Tools::get_taxonomies(),
							'default' => 'product_cat',
							'disabled' => 'disabled',
							'name' => __( 'Taxonomy', 'tp' ),
							'desc' => __( 'Select taxonomy to show posts from', 'tp' )
						),
						'category' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Tp_Tools::get_terms( 'product_cat', 'slug' ),
							'default' => '',
							'name' => __( 'Terms', 'tp' ),
							'desc' => __( 'Select terms to show posts from', 'tp' )
						),

						'per_page' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 50,
							'step' => 1,
							'default' => 12,
							'name' => __( 'Per page', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'columns' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 4,
							'step' => 1,
							'default' => $cc,
							'name' => __( 'Columns', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'tp' ),
								'id' => __( 'Post ID', 'tp' ),
								'count' => __( 'Count', 'tp' ),
								'name' => __( 'Name', 'tp' ),
								'slug' => __( 'Slug', 'tp' ),
							),
							'default' => 'name',
							'name' => __( 'Order by', 'tp' ),
							'desc' => __( 'Order posts by', 'tp' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'tp' ),
								'asc' => __( 'Ascending', 'tp' )
							),
							'default' => 'asc',
							'name' => __( 'Order', 'tp' ),
							'desc' => __( 'Posts order', 'tp' )
						),
					),
					'desc' => __( 'Multiple Product', 'tp' ),
					'icon' => 'files-o'
				);

			//Product Categories  
			$shortcodes['product_categories'] = 
				array(
					'name' => __( 'Product Categories', 'tp' ),
					'type' => 'single',
					'group' => 'product',
					'atts' => array(
						'columns' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 4,
							'step' => 1,
							'default' => $pc,
							'name' => __( 'Columns', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'tp' ),
								'id' => __( 'Post ID', 'tp' ),
								'count' => __( 'Count', 'tp' ),
								'name' => __( 'Name', 'tp' ),
								'slug' => __( 'Slug', 'tp' ),
							),
							'default' => 'name',
							'name' => __( 'Order by', 'tp' ),
							'desc' => __( 'Order posts by', 'tp' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'tp' ),
								'asc' => __( 'Ascending', 'tp' )
							),
							'default' => 'asc',
							'name' => __( 'Order', 'tp' ),
							'desc' => __( 'Posts order', 'tp' )
						),
						'taxonomy' => array(
							'type' => 'select',
							'values' => Tp_Tools::get_taxonomies(),
							'default' => 'product_cat',
							'disabled' => 'disabled',
							'name' => __( 'Taxonomy', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'ids' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Tp_Tools::get_terms( 'product_cat' ),
							'default' => '',
							'name' => __( 'Terms', 'tp' ),
							'desc' => __( '`ids` field is to tell the shortcode which categories to display.', 'tp' )
						),
					),
					'desc' => __( 'Multiple Product', 'tp' ),
					'icon' => 'file-text-o'
				);

			//Products display 

			$shortcodes['products_display'] = 
				array(
					'name' => __( 'Products display', 'tp' ),
					'type' => 'single',
					'group' => 'product',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
									'recent_products' => __( 'Recent products', 'tp' ),
									'featured_products' => __( 'Featured Products', 'tp' ),
									'sale_products' => __( 'Sale Products', 'tp' ),
									'best_selling_products' => __( 'Best Selling Products', 'tp' ),
									'top_rated_products' => __( 'Top Rated Products', 'tp' ),
									'related_products' => __( 'Related Products', 'tp' ),
								),
							'default' => 'recent_products',
							'name' => __( 'Product type', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'per_page' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 50,
							'step' => 1,
							'default' => 12,
							'name' => __( 'Per page', 'tp' ),
							'desc' => __( 'the ‘per_page’ shortcode argument will determine how many products are shown on a page. This will not add pagination to the shortcode.', 'tp' )
						),
						'columns' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 4,
							'step' => 1,
							'default' => $pc,
							'name' => __( 'Columns', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'tp' ),
								'id' => __( 'Post ID', 'tp' ),
								'author' => __( 'Post author', 'tp' ),
								'title' => __( 'Post title', 'tp' ),
								'name' => __( 'Post slug', 'tp' ),
								'date' => __( 'Date', 'tp' ), 'modified' => __( 'Last modified date', 'tp' ),
								'parent' => __( 'Post parent', 'tp' ),
								'rand' => __( 'Random', 'tp' ), 'comment_count' => __( 'Comments number', 'tp' ),
								'menu_order' => __( 'Menu order', 'tp' ), 'meta_value' => __( 'Meta key values', 'tp' ),
							),
							'default' => 'title',
							'name' => __( 'Order by', 'tp' ),
							'desc' => __( 'Order posts by', 'tp' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'tp' ),
								'asc' => __( 'Ascending', 'tp' )
							),
							'default' => 'asc',
							'name' => __( 'Order', 'tp' ),
							'desc' => __( 'Posts order', 'tp' )
						),
					),
					'desc' => __( '', 'tp' ),
					'icon' => 'files-o'
				);

			//products	
			$shortcodes['products_carousel'] = 
				array(
					'name' => __( 'Products carousel', 'tp' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'ids' => array(
							'type' => 'select',
							'values' => Tp_Tools::get_posts_dropdown( array('post_type'=> 'product', 'posts_per_page' => -1) ),
							'default' => '',
							'multiple' => 'multiple',
							'name' => __( 'Product lists', 'tp' ),
							'desc' => 'Select a product'
						),
						'columns' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 4,
							'step' => 1,
							'default' => 4,
							'name' => __( 'Columns', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'navigation' => array(
							'type' => 'bool',							
							'default' => 'no',
							'name' => __( 'Navigation', 'tp' ),
							'desc' => __( '', 'tp' )
						),
						'pagination' => array(
							'type' => 'bool',							
							'default' => 'yes',
							'name' => __( 'Pagination', 'tp' ),
							'desc' => __( '', 'tp' )
						),
					),
					'desc' => __( 'Multiple Product', 'tp' ),
					'icon' => 'files-o'
				);
			

			




		// Return result
		return ( is_string( $shortcode ) ) ? $shortcodes[sanitize_text_field( $shortcode )] : $shortcodes;
	}
}

class Perch_Shortcodes_Data extends Tp_Data {
	function __construct() {
		parent::__construct();
	}
}

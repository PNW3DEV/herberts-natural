<?php
/*
  Plugin Name: Perch Shortcodes
  Plugin URI: http://themeforest.net/user/themeperch?ref=themeperch
  Version: 1.2
  Author: ThemePerch
  Author URI: http://themeforest.net/user/themeperch?ref=themeperch
  Description: Supercharge your WordPress theme with mega pack of shortcodes
  Text Domain: tp
  Domain Path: /languages
  License: GPL
 */

// Define plugin constants
define( 'TP_PLUGIN_FILE', __FILE__ );
define( 'TP_PLUGIN_VERSION', '1.2' );
define( 'TP_ENABLE_CACHE', true );

// Includes
require_once 'inc/vendor/sunrise.php';
require_once 'inc/core/admin-views.php';
require_once 'inc/core/requirements.php';
require_once 'inc/core/load.php';
require_once 'inc/core/assets.php';
require_once 'inc/core/shortcodes.php';
require_once 'inc/core/tools.php';
require_once 'inc/core/data.php';
require_once 'inc/core/generator-views.php';
require_once 'inc/core/generator.php';
require_once 'inc/core/widget.php';

